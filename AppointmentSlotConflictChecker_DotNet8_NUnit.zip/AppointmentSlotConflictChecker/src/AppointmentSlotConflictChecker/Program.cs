using AppointmentSlotConflictChecker.Models;
using AppointmentSlotConflictChecker.Services;

namespace AppointmentSlotConflictChecker;

internal class Program
{
    private static void Main(string[] args)
    {
        IAppointmentValidator validator = new AppointmentValidator();

        var appointments = GetSampleAppointments();

        Console.WriteLine("APPOINTMENT SLOT CONFLICT CHECKER");
        Console.WriteLine("--------------------------------");
        Console.WriteLine();

        Console.WriteLine("Input Appointments:");
        foreach (var appointment in appointments)
        {
            Console.WriteLine(appointment);
        }

        Console.WriteLine();
        Console.WriteLine("Validation Result:");
        var validationErrors = validator.ValidateAppointments(appointments);

        if (validationErrors.Count == 0)
        {
            Console.WriteLine("No validation errors found.");
        }
        else
        {
            foreach (var error in validationErrors)
            {
                Console.WriteLine(error);
            }
        }

        Console.WriteLine();
        Console.WriteLine("Conflict Result:");
        var conflicts = validator.FindConflictingAppointments(appointments);

        if (conflicts.Count == 0)
        {
            Console.WriteLine("No appointment conflicts found.");
        }
        else
        {
            foreach (var conflict in conflicts)
            {
                Console.WriteLine(conflict);
            }
        }

        Console.WriteLine();
        Console.WriteLine("Upcoming Booked Appointments:");
        var upcomingAppointments = validator.GetUpcomingBookedAppointments(
            appointments,
            new DateTime(2026, 7, 1, 9, 0, 0));

        foreach (var appointment in upcomingAppointments)
        {
            Console.WriteLine($"{appointment.PatientName} - Doctor {appointment.DoctorId} - {appointment.AppointmentTime:dd-MM-yyyy HH:mm}");
        }

        Console.WriteLine();
        Console.WriteLine("Doctor-Wise Appointment Summary:");
        var summaries = validator.GetDoctorWiseSummary(appointments);

        foreach (var summary in summaries)
        {
            Console.WriteLine($"Doctor {summary.DoctorId}: Total={summary.TotalAppointments}, Booked={summary.BookedAppointments}, Cancelled={summary.CancelledAppointments}, Completed={summary.CompletedAppointments}");
        }
    }

    private static List<Appointment> GetSampleAppointments()
    {
        return new List<Appointment>
        {
            new Appointment
            {
                AppointmentId = 1,
                DoctorId = 101,
                PatientName = "Arun",
                AppointmentTime = new DateTime(2026, 7, 1, 10, 0, 0),
                DurationMinutes = 30,
                Status = AppointmentStatus.Booked
            },
            new Appointment
            {
                AppointmentId = 2,
                DoctorId = 101,
                PatientName = "Priya",
                AppointmentTime = new DateTime(2026, 7, 1, 10, 15, 0),
                DurationMinutes = 30,
                Status = AppointmentStatus.Booked
            },
            new Appointment
            {
                AppointmentId = 3,
                DoctorId = 102,
                PatientName = "Kumar",
                AppointmentTime = new DateTime(2026, 7, 1, 11, 0, 0),
                DurationMinutes = 30,
                Status = AppointmentStatus.Booked
            },
            new Appointment
            {
                AppointmentId = 4,
                DoctorId = 101,
                PatientName = "Divya",
                AppointmentTime = new DateTime(2026, 7, 1, 12, 0, 0),
                DurationMinutes = 30,
                Status = AppointmentStatus.Booked
            },
            new Appointment
            {
                AppointmentId = 5,
                DoctorId = 101,
                PatientName = "Meena",
                AppointmentTime = new DateTime(2026, 7, 1, 10, 0, 0),
                DurationMinutes = 15,
                Status = AppointmentStatus.Cancelled
            },
            new Appointment
            {
                AppointmentId = 6,
                DoctorId = 103,
                PatientName = "Ravi",
                AppointmentTime = new DateTime(2026, 7, 2, 9, 30, 0),
                DurationMinutes = 45,
                Status = AppointmentStatus.Completed
            },
            new Appointment
            {
                AppointmentId = 7,
                DoctorId = 104,
                PatientName = "",
                AppointmentTime = new DateTime(2026, 7, 2, 9, 30, 0),
                DurationMinutes = 0,
                Status = AppointmentStatus.Booked
            }
        };
    }
}
