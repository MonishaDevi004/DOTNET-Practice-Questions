namespace AppointmentSlotConflictChecker.Models;

public class DoctorAppointmentSummary
{
    public int DoctorId { get; set; }
    public int TotalAppointments { get; set; }
    public int BookedAppointments { get; set; }
    public int CancelledAppointments { get; set; }
    public int CompletedAppointments { get; set; }
}
