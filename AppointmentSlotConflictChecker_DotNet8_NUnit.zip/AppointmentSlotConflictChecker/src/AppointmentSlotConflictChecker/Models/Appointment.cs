namespace AppointmentSlotConflictChecker.Models;

public class Appointment
{
    public int AppointmentId { get; set; }
    public int DoctorId { get; set; }
    public string PatientName { get; set; } = string.Empty;
    public DateTime AppointmentTime { get; set; }
    public int DurationMinutes { get; set; }
    public AppointmentStatus Status { get; set; }

    public DateTime EndTime => AppointmentTime.AddMinutes(DurationMinutes);

    public override string ToString()
    {
        return $"AppointmentId: {AppointmentId}, DoctorId: {DoctorId}, Patient: {PatientName}, Time: {AppointmentTime:dd-MM-yyyy HH:mm}, Duration: {DurationMinutes}, Status: {Status}";
    }
}
