namespace AppointmentSlotConflictChecker.Models;

public class AppointmentConflict
{
    public int DoctorId { get; set; }
    public int FirstAppointmentId { get; set; }
    public int SecondAppointmentId { get; set; }
    public string FirstPatientName { get; set; } = string.Empty;
    public string SecondPatientName { get; set; } = string.Empty;
    public DateTime FirstStartTime { get; set; }
    public DateTime FirstEndTime { get; set; }
    public DateTime SecondStartTime { get; set; }
    public DateTime SecondEndTime { get; set; }
    public string Reason { get; set; } = string.Empty;

    public override string ToString()
    {
        return $"Doctor {DoctorId} conflict: {FirstPatientName} ({FirstStartTime:dd-MM-yyyy HH:mm} - {FirstEndTime:HH:mm}) " +
               $"and {SecondPatientName} ({SecondStartTime:dd-MM-yyyy HH:mm} - {SecondEndTime:HH:mm}) - {Reason}";
    }
}
