using AppointmentSlotConflictChecker.Models;

namespace AppointmentSlotConflictChecker.Services;

public class AppointmentValidator : IAppointmentValidator
{
    public List<AppointmentConflict> FindConflictingAppointments(List<Appointment> appointments)
    {
        if (appointments == null || appointments.Count == 0)
        {
            return new List<AppointmentConflict>();
        }

        var activeAppointments = appointments
            .Where(a => a.Status == AppointmentStatus.Booked)
            .Where(a => a.DurationMinutes > 0)
            .OrderBy(a => a.DoctorId)
            .ThenBy(a => a.AppointmentTime)
            .ToList();

        var conflicts = new List<AppointmentConflict>();

        foreach (var doctorGroup in activeAppointments.GroupBy(a => a.DoctorId))
        {
            var doctorAppointments = doctorGroup
                .OrderBy(a => a.AppointmentTime)
                .ToList();

            for (int i = 0; i < doctorAppointments.Count; i++)
            {
                for (int j = i + 1; j < doctorAppointments.Count; j++)
                {
                    var first = doctorAppointments[i];
                    var second = doctorAppointments[j];

                    if (second.AppointmentTime >= first.EndTime)
                    {
                        break;
                    }

                    if (IsOverlapping(first, second))
                    {
                        conflicts.Add(new AppointmentConflict
                        {
                            DoctorId = first.DoctorId,
                            FirstAppointmentId = first.AppointmentId,
                            SecondAppointmentId = second.AppointmentId,
                            FirstPatientName = first.PatientName,
                            SecondPatientName = second.PatientName,
                            FirstStartTime = first.AppointmentTime,
                            FirstEndTime = first.EndTime,
                            SecondStartTime = second.AppointmentTime,
                            SecondEndTime = second.EndTime,
                            Reason = first.AppointmentTime == second.AppointmentTime
                                ? "Duplicate appointment slot"
                                : "Overlapping appointment slot"
                        });
                    }
                }
            }
        }

        return conflicts;
    }

    public List<string> ValidateAppointments(List<Appointment> appointments)
    {
        var errors = new List<string>();

        if (appointments == null)
        {
            errors.Add("Appointment list cannot be null.");
            return errors;
        }

        foreach (var appointment in appointments)
        {
            if (appointment.AppointmentId <= 0)
            {
                errors.Add("Appointment id must be greater than zero.");
            }

            if (appointment.DoctorId <= 0)
            {
                errors.Add($"Appointment {appointment.AppointmentId}: Doctor id must be greater than zero.");
            }

            if (string.IsNullOrWhiteSpace(appointment.PatientName))
            {
                errors.Add($"Appointment {appointment.AppointmentId}: Patient name is required.");
            }

            if (appointment.DurationMinutes <= 0)
            {
                errors.Add($"Appointment {appointment.AppointmentId}: Duration must be greater than zero.");
            }

            if (!Enum.IsDefined(typeof(AppointmentStatus), appointment.Status))
            {
                errors.Add($"Appointment {appointment.AppointmentId}: Invalid appointment status.");
            }
        }

        return errors;
    }

    public List<Appointment> GetUpcomingBookedAppointments(List<Appointment> appointments, DateTime currentDateTime)
    {
        if (appointments == null || appointments.Count == 0)
        {
            return new List<Appointment>();
        }

        return appointments
            .Where(a => a.Status == AppointmentStatus.Booked)
            .Where(a => a.AppointmentTime > currentDateTime)
            .OrderBy(a => a.AppointmentTime)
            .ThenBy(a => a.DoctorId)
            .ToList();
    }

    public List<DoctorAppointmentSummary> GetDoctorWiseSummary(List<Appointment> appointments)
    {
        if (appointments == null || appointments.Count == 0)
        {
            return new List<DoctorAppointmentSummary>();
        }

        return appointments
            .GroupBy(a => a.DoctorId)
            .Select(g => new DoctorAppointmentSummary
            {
                DoctorId = g.Key,
                TotalAppointments = g.Count(),
                BookedAppointments = g.Count(a => a.Status == AppointmentStatus.Booked),
                CancelledAppointments = g.Count(a => a.Status == AppointmentStatus.Cancelled),
                CompletedAppointments = g.Count(a => a.Status == AppointmentStatus.Completed)
            })
            .OrderBy(x => x.DoctorId)
            .ToList();
    }

    private static bool IsOverlapping(Appointment first, Appointment second)
    {
        return first.AppointmentTime < second.EndTime &&
               second.AppointmentTime < first.EndTime;
    }
}
