using AppointmentSlotConflictChecker.Models;

namespace AppointmentSlotConflictChecker.Services;

public interface IAppointmentValidator
{
    List<AppointmentConflict> FindConflictingAppointments(List<Appointment> appointments);
    List<string> ValidateAppointments(List<Appointment> appointments);
    List<Appointment> GetUpcomingBookedAppointments(List<Appointment> appointments, DateTime currentDateTime);
    List<DoctorAppointmentSummary> GetDoctorWiseSummary(List<Appointment> appointments);
}
