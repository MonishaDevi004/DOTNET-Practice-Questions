using AppointmentSlotConflictChecker.Models;
using AppointmentSlotConflictChecker.Services;
using NUnit.Framework;

namespace AppointmentSlotConflictChecker.Tests;

[TestFixture]
public class AppointmentValidatorTests
{
    private AppointmentValidator _validator = null!;

    [SetUp]
    public void Setup()
    {
        _validator = new AppointmentValidator();
    }

    [Test]
    public void FindConflictingAppointments_WhenSameDoctorAppointmentsOverlap_ReturnsConflict()
    {
        var appointments = new List<Appointment>
        {
            CreateAppointment(1, 101, "Arun", new DateTime(2026, 7, 1, 10, 0, 0), 30, AppointmentStatus.Booked),
            CreateAppointment(2, 101, "Priya", new DateTime(2026, 7, 1, 10, 15, 0), 30, AppointmentStatus.Booked)
        };

        var conflicts = _validator.FindConflictingAppointments(appointments);

        Assert.That(conflicts, Has.Count.EqualTo(1));
        Assert.That(conflicts[0].DoctorId, Is.EqualTo(101));
        Assert.That(conflicts[0].Reason, Is.EqualTo("Overlapping appointment slot"));
    }

    [Test]
    public void FindConflictingAppointments_WhenSameDoctorSameStartTime_ReturnsDuplicateSlotConflict()
    {
        var appointments = new List<Appointment>
        {
            CreateAppointment(1, 101, "Arun", new DateTime(2026, 7, 1, 10, 0, 0), 30, AppointmentStatus.Booked),
            CreateAppointment(2, 101, "Priya", new DateTime(2026, 7, 1, 10, 0, 0), 30, AppointmentStatus.Booked)
        };

        var conflicts = _validator.FindConflictingAppointments(appointments);

        Assert.That(conflicts, Has.Count.EqualTo(1));
        Assert.That(conflicts[0].Reason, Is.EqualTo("Duplicate appointment slot"));
    }

    [Test]
    public void FindConflictingAppointments_WhenAppointmentsAreForDifferentDoctors_ReturnsNoConflict()
    {
        var appointments = new List<Appointment>
        {
            CreateAppointment(1, 101, "Arun", new DateTime(2026, 7, 1, 10, 0, 0), 30, AppointmentStatus.Booked),
            CreateAppointment(2, 102, "Priya", new DateTime(2026, 7, 1, 10, 15, 0), 30, AppointmentStatus.Booked)
        };

        var conflicts = _validator.FindConflictingAppointments(appointments);

        Assert.That(conflicts, Is.Empty);
    }

    [Test]
    public void FindConflictingAppointments_WhenAppointmentStartsAtPreviousEndTime_ReturnsNoConflict()
    {
        var appointments = new List<Appointment>
        {
            CreateAppointment(1, 101, "Arun", new DateTime(2026, 7, 1, 10, 0, 0), 30, AppointmentStatus.Booked),
            CreateAppointment(2, 101, "Priya", new DateTime(2026, 7, 1, 10, 30, 0), 30, AppointmentStatus.Booked)
        };

        var conflicts = _validator.FindConflictingAppointments(appointments);

        Assert.That(conflicts, Is.Empty);
    }

    [Test]
    public void FindConflictingAppointments_WhenOneAppointmentCancelled_IgnoresCancelledAppointment()
    {
        var appointments = new List<Appointment>
        {
            CreateAppointment(1, 101, "Arun", new DateTime(2026, 7, 1, 10, 0, 0), 30, AppointmentStatus.Booked),
            CreateAppointment(2, 101, "Priya", new DateTime(2026, 7, 1, 10, 15, 0), 30, AppointmentStatus.Cancelled)
        };

        var conflicts = _validator.FindConflictingAppointments(appointments);

        Assert.That(conflicts, Is.Empty);
    }

    [Test]
    public void FindConflictingAppointments_WhenInputIsNull_ReturnsEmptyList()
    {
        var conflicts = _validator.FindConflictingAppointments(null!);

        Assert.That(conflicts, Is.Empty);
    }

    [Test]
    public void ValidateAppointments_WhenPatientNameIsEmpty_ReturnsValidationError()
    {
        var appointments = new List<Appointment>
        {
            CreateAppointment(1, 101, "", new DateTime(2026, 7, 1, 10, 0, 0), 30, AppointmentStatus.Booked)
        };

        var errors = _validator.ValidateAppointments(appointments);

        Assert.That(errors, Has.Count.EqualTo(1));
        Assert.That(errors[0], Does.Contain("Patient name is required"));
    }

    [Test]
    public void ValidateAppointments_WhenDurationIsZero_ReturnsValidationError()
    {
        var appointments = new List<Appointment>
        {
            CreateAppointment(1, 101, "Arun", new DateTime(2026, 7, 1, 10, 0, 0), 0, AppointmentStatus.Booked)
        };

        var errors = _validator.ValidateAppointments(appointments);

        Assert.That(errors, Has.Count.EqualTo(1));
        Assert.That(errors[0], Does.Contain("Duration must be greater than zero"));
    }

    [Test]
    public void GetUpcomingBookedAppointments_ReturnsOnlyFutureBookedAppointments()
    {
        var currentDateTime = new DateTime(2026, 7, 1, 9, 0, 0);

        var appointments = new List<Appointment>
        {
            CreateAppointment(1, 101, "Past", new DateTime(2026, 7, 1, 8, 0, 0), 30, AppointmentStatus.Booked),
            CreateAppointment(2, 101, "Future", new DateTime(2026, 7, 1, 10, 0, 0), 30, AppointmentStatus.Booked),
            CreateAppointment(3, 101, "Cancelled", new DateTime(2026, 7, 1, 11, 0, 0), 30, AppointmentStatus.Cancelled)
        };

        var result = _validator.GetUpcomingBookedAppointments(appointments, currentDateTime);

        Assert.That(result, Has.Count.EqualTo(1));
        Assert.That(result[0].PatientName, Is.EqualTo("Future"));
    }

    [Test]
    public void GetDoctorWiseSummary_ReturnsCorrectCounts()
    {
        var appointments = new List<Appointment>
        {
            CreateAppointment(1, 101, "A", new DateTime(2026, 7, 1, 10, 0, 0), 30, AppointmentStatus.Booked),
            CreateAppointment(2, 101, "B", new DateTime(2026, 7, 1, 11, 0, 0), 30, AppointmentStatus.Cancelled),
            CreateAppointment(3, 101, "C", new DateTime(2026, 7, 1, 12, 0, 0), 30, AppointmentStatus.Completed),
            CreateAppointment(4, 102, "D", new DateTime(2026, 7, 1, 13, 0, 0), 30, AppointmentStatus.Booked)
        };

        var result = _validator.GetDoctorWiseSummary(appointments);

        Assert.That(result, Has.Count.EqualTo(2));

        var doctor101 = result.First(x => x.DoctorId == 101);

        Assert.That(doctor101.TotalAppointments, Is.EqualTo(3));
        Assert.That(doctor101.BookedAppointments, Is.EqualTo(1));
        Assert.That(doctor101.CancelledAppointments, Is.EqualTo(1));
        Assert.That(doctor101.CompletedAppointments, Is.EqualTo(1));
    }

    private static Appointment CreateAppointment(
        int appointmentId,
        int doctorId,
        string patientName,
        DateTime appointmentTime,
        int durationMinutes,
        AppointmentStatus status)
    {
        return new Appointment
        {
            AppointmentId = appointmentId,
            DoctorId = doctorId,
            PatientName = patientName,
            AppointmentTime = appointmentTime,
            DurationMinutes = durationMinutes,
            Status = status
        };
    }
}
