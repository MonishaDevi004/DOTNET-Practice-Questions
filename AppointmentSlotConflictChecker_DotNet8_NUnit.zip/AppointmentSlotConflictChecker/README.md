# Appointment Slot Conflict Checker - .NET 8 Console Application

## Purpose

This is a ready-to-use intermediate-level C# .NET 8 coding challenge project for Karat-style interview preparation.

The application validates hospital appointment slots and detects scheduling conflicts for doctors.

## Technologies Used

- .NET SDK 8.0
- C# 12
- Console Application
- NUnit
- NUnit3TestAdapter
- Microsoft.NET.Test.Sdk

---

## Business Scenario

A hospital appointment system should detect duplicate or overlapping appointment slots for the same doctor.

The system must support:

1. Appointment slot conflict detection
2. Duplicate same-time appointment detection
3. Overlapping appointment detection based on appointment duration
4. Cancelled appointment exclusion
5. Completed appointment exclusion
6. Invalid appointment validation
7. Doctor-wise appointment summary
8. Upcoming appointment filtering
9. NUnit test coverage

---

## Project Structure

```text
AppointmentSlotConflictChecker
│
├── AppointmentSlotConflictChecker.sln
│
├── RUN_COMMANDS.txt
├── README.md
│
├── src
│   └── AppointmentSlotConflictChecker
│       ├── AppointmentSlotConflictChecker.csproj
│       ├── Program.cs
│       ├── Models
│       │   ├── Appointment.cs
│       │   ├── AppointmentConflict.cs
│       │   ├── AppointmentStatus.cs
│       │   └── DoctorAppointmentSummary.cs
│       └── Services
│           ├── IAppointmentValidator.cs
│           └── AppointmentValidator.cs
│
└── tests
    └── AppointmentSlotConflictChecker.Tests
        ├── AppointmentSlotConflictChecker.Tests.csproj
        └── AppointmentValidatorTests.cs
```

---

## How to Run

Open terminal from the root folder:

```bash
dotnet restore
dotnet build
dotnet run --project src/AppointmentSlotConflictChecker/AppointmentSlotConflictChecker.csproj
```

---

## How to Run Tests

```bash
dotnet test
```

---

## Challenge: Appointment Slot Conflict Checker

A hospital appointment system should detect conflicts in doctor appointment schedules.

Two appointments conflict when:

1. They belong to the same doctor.
2. Both appointments are active/booked.
3. Their appointment time ranges overlap.

Cancelled and completed appointments should not be considered as conflicts.

---

## Added Complexity

This version checks:

- Same doctor conflict
- Overlapping time ranges
- Duplicate same-time slot
- Cancelled appointment exclusion
- Completed appointment exclusion
- Invalid duration
- Empty patient name
- Doctor-wise appointment summary
- Upcoming booked appointments
- Edge cases through NUnit tests

---

## Main Interview Evaluation Areas

| Skill | What to Observe |
|---|---|
| OOPS | Uses models, service interface, and clean class design |
| Collections | Works with `List<T>` properly |
| LINQ | Uses filtering, grouping, ordering, and projection |
| DateTime | Handles appointment start and end time correctly |
| Bug Fixing | Candidate should identify overlapping logic problems |
| Edge Cases | Handles null, empty, cancelled, completed, and invalid records |
| Testing | Candidate writes NUnit tests for business rules |
| Communication | Candidate explains approach clearly |
