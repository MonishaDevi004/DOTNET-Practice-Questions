using CustomerDuplicateDetection.Data;
using CustomerDuplicateDetection.Services;

namespace CustomerDuplicateDetection;

internal class Program
{
    private static void Main(string[] args)
    {
        ICustomerDuplicateDetector detector = new CustomerDuplicateDetector();

        var customers = SampleCustomerData.GetCustomers();

        Console.WriteLine("CUSTOMER DUPLICATE DETECTION");
        Console.WriteLine("----------------------------");
        Console.WriteLine();

        Console.WriteLine("Input Customers:");
        foreach (var customer in customers)
        {
            Console.WriteLine(customer);
        }

        Console.WriteLine();
        Console.WriteLine("Invalid Customer Records:");
        var invalidRecords = detector.ValidateCustomers(customers);

        if (invalidRecords.Count == 0)
        {
            Console.WriteLine("No invalid records found.");
        }
        else
        {
            foreach (var record in invalidRecords)
            {
                Console.WriteLine(record);
            }
        }

        Console.WriteLine();
        Console.WriteLine("Duplicate Groups:");
        var duplicateGroups = detector.FindDuplicateGroups(customers);

        if (duplicateGroups.Count == 0)
        {
            Console.WriteLine("No duplicate customers found.");
        }
        else
        {
            foreach (var group in duplicateGroups)
            {
                Console.WriteLine(group);
            }
        }

        Console.WriteLine();
        Console.WriteLine("Unique Customers:");
        var uniqueCustomers = detector.GetUniqueCustomers(customers);

        foreach (var customer in uniqueCustomers)
        {
            Console.WriteLine(customer);
        }

        Console.WriteLine();
        Console.WriteLine("Source-Wise Summary:");
        var sourceSummary = detector.GetSourceWiseSummary(customers);

        foreach (var summary in sourceSummary)
        {
            Console.WriteLine(summary);
        }
    }
}
