namespace CustomerDuplicateDetection.Models;

public class InvalidCustomerRecord
{
    public int CustomerId { get; set; }
    public string Reason { get; set; } = string.Empty;

    public override string ToString()
    {
        return $"CustomerId: {CustomerId}, Reason: {Reason}";
    }
}
