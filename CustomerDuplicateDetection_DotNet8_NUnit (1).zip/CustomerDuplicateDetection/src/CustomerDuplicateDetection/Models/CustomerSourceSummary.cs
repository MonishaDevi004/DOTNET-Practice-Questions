namespace CustomerDuplicateDetection.Models;

public class CustomerSourceSummary
{
    public string Source { get; set; } = string.Empty;
    public int Count { get; set; }

    public override string ToString()
    {
        return $"{Source} - {Count}";
    }
}
