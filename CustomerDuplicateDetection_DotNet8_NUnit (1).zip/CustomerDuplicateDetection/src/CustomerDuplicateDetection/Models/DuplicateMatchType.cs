namespace CustomerDuplicateDetection.Models;

public enum DuplicateMatchType
{
    Email = 1,
    MobileNumber = 2,
    NameAndDateOfBirth = 3
}
