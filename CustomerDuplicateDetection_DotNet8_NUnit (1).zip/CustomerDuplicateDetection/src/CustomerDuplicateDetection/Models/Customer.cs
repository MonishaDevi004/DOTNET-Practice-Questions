namespace CustomerDuplicateDetection.Models;

public class Customer
{
    public int CustomerId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string MobileNumber { get; set; } = string.Empty;
    public DateTime? DateOfBirth { get; set; }
    public string Source { get; set; } = string.Empty;

    public override string ToString()
    {
        string dob = DateOfBirth.HasValue ? DateOfBirth.Value.ToString("yyyy-MM-dd") : "N/A";
        return $"{CustomerId} - {FullName} - {Email} - {MobileNumber} - {dob} - {Source}";
    }
}
