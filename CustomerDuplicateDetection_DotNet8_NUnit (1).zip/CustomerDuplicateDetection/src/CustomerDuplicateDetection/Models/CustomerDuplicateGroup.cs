namespace CustomerDuplicateDetection.Models;

public class CustomerDuplicateGroup
{
    public DuplicateMatchType MatchType { get; set; }
    public string MatchKey { get; set; } = string.Empty;
    public List<int> CustomerIds { get; set; } = new();
    public List<string> CustomerNames { get; set; } = new();

    public override string ToString()
    {
        return $"{MatchType} - {MatchKey} - CustomerIds: {string.Join(", ", CustomerIds)} - Names: {string.Join(", ", CustomerNames)}";
    }
}
