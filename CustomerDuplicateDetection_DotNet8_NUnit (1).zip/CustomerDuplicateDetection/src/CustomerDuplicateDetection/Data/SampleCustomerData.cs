using CustomerDuplicateDetection.Models;

namespace CustomerDuplicateDetection.Data;

public static class SampleCustomerData
{
    public static List<Customer> GetCustomers()
    {
        return new List<Customer>
        {
            new Customer
            {
                CustomerId = 1,
                FullName = "Arun Kumar",
                Email = "arun@test.com",
                MobileNumber = "9876543210",
                DateOfBirth = new DateTime(1995, 5, 10),
                Source = "Website"
            },
            new Customer
            {
                CustomerId = 2,
                FullName = "Priya Sharma",
                Email = "priya@test.com",
                MobileNumber = "9123456789",
                DateOfBirth = new DateTime(1996, 7, 12),
                Source = "MobileApp"
            },
            new Customer
            {
                CustomerId = 3,
                FullName = "Arun Kumar",
                Email = " ARUN@test.com ",
                MobileNumber = "98765-43210",
                DateOfBirth = new DateTime(1995, 5, 10),
                Source = "CRM"
            },
            new Customer
            {
                CustomerId = 4,
                FullName = "Divya Raj",
                Email = "divya@test.com",
                MobileNumber = "9988776655",
                DateOfBirth = new DateTime(1994, 1, 20),
                Source = "Branch"
            },
            new Customer
            {
                CustomerId = 5,
                FullName = "Priya Sharma",
                Email = "priya.new@test.com",
                MobileNumber = "9123456789",
                DateOfBirth = new DateTime(1996, 7, 12),
                Source = "CRM"
            },
            new Customer
            {
                CustomerId = 6,
                FullName = "",
                Email = "invalid@test.com",
                MobileNumber = "8123456789",
                DateOfBirth = new DateTime(1992, 6, 5),
                Source = "Website"
            },
            new Customer
            {
                CustomerId = 7,
                FullName = "Kumar",
                Email = "wrong-email",
                MobileNumber = "12345",
                DateOfBirth = null,
                Source = ""
            }
        };
    }
}
