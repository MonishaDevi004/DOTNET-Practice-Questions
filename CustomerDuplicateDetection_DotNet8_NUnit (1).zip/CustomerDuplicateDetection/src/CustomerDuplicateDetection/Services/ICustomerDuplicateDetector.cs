using CustomerDuplicateDetection.Models;

namespace CustomerDuplicateDetection.Services;

public interface ICustomerDuplicateDetector
{
    List<CustomerDuplicateGroup> FindDuplicateGroups(List<Customer> customers);
    List<InvalidCustomerRecord> ValidateCustomers(List<Customer> customers);
    List<Customer> GetUniqueCustomers(List<Customer> customers);
    List<CustomerSourceSummary> GetSourceWiseSummary(List<Customer> customers);
}
