using CustomerDuplicateDetection.Models;

namespace CustomerDuplicateDetection.Services;

public class CustomerDuplicateDetector : ICustomerDuplicateDetector
{
    public List<CustomerDuplicateGroup> FindDuplicateGroups(List<Customer> customers)
    {
        if (customers == null || customers.Count == 0)
        {
            return new List<CustomerDuplicateGroup>();
        }

        var validCustomers = customers
            .Where(IsValidForDuplicateProcessing)
            .ToList();

        var duplicateGroups = new List<CustomerDuplicateGroup>();

        duplicateGroups.AddRange(FindDuplicatesByKey(
            validCustomers,
            DuplicateMatchType.Email,
            c => NormalizeEmail(c.Email)));

        duplicateGroups.AddRange(FindDuplicatesByKey(
            validCustomers,
            DuplicateMatchType.MobileNumber,
            c => NormalizeMobile(c.MobileNumber)));

        duplicateGroups.AddRange(FindDuplicatesByKey(
            validCustomers,
            DuplicateMatchType.NameAndDateOfBirth,
            c => CreateNameDobKey(c)));

        return duplicateGroups
            .OrderBy(g => g.MatchType)
            .ThenBy(g => g.MatchKey)
            .ToList();
    }

    public List<InvalidCustomerRecord> ValidateCustomers(List<Customer> customers)
    {
        var invalidRecords = new List<InvalidCustomerRecord>();

        if (customers == null)
        {
            invalidRecords.Add(new InvalidCustomerRecord
            {
                CustomerId = 0,
                Reason = "Customer list cannot be null."
            });

            return invalidRecords;
        }

        foreach (var customer in customers)
        {
            if (customer == null)
            {
                invalidRecords.Add(new InvalidCustomerRecord
                {
                    CustomerId = 0,
                    Reason = "Customer record cannot be null."
                });

                continue;
            }

            var reasons = new List<string>();

            if (customer.CustomerId <= 0)
            {
                reasons.Add("Customer id must be greater than zero");
            }

            if (string.IsNullOrWhiteSpace(customer.FullName))
            {
                reasons.Add("Full name is required");
            }

            if (!IsValidEmail(customer.Email))
            {
                reasons.Add("Valid email is required");
            }

            if (!IsValidMobile(customer.MobileNumber))
            {
                reasons.Add("Valid 10 digit mobile number is required");
            }

            if (!customer.DateOfBirth.HasValue)
            {
                reasons.Add("Date of birth is required");
            }

            if (string.IsNullOrWhiteSpace(customer.Source))
            {
                reasons.Add("Source is required");
            }

            if (reasons.Count > 0)
            {
                invalidRecords.Add(new InvalidCustomerRecord
                {
                    CustomerId = customer.CustomerId,
                    Reason = string.Join("; ", reasons)
                });
            }
        }

        return invalidRecords;
    }

    public List<Customer> GetUniqueCustomers(List<Customer> customers)
    {
        if (customers == null || customers.Count == 0)
        {
            return new List<Customer>();
        }

        var validCustomers = customers
            .Where(IsValidForDuplicateProcessing)
            .OrderBy(c => c.CustomerId)
            .ToList();

        var seenKeys = new HashSet<string>();
        var uniqueCustomers = new List<Customer>();

        foreach (var customer in validCustomers)
        {
            var possibleKeys = new[]
            {
                $"EMAIL:{NormalizeEmail(customer.Email)}",
                $"MOBILE:{NormalizeMobile(customer.MobileNumber)}",
                $"NAMEDOB:{CreateNameDobKey(customer)}"
            };

            if (possibleKeys.Any(key => seenKeys.Contains(key)))
            {
                continue;
            }

            uniqueCustomers.Add(customer);

            foreach (var key in possibleKeys)
            {
                seenKeys.Add(key);
            }
        }

        return uniqueCustomers;
    }

    public List<CustomerSourceSummary> GetSourceWiseSummary(List<Customer> customers)
    {
        if (customers == null || customers.Count == 0)
        {
            return new List<CustomerSourceSummary>();
        }

        return customers
            .Where(c => c != null)
            .GroupBy(c => string.IsNullOrWhiteSpace(c.Source) ? "Unknown" : c.Source.Trim())
            .Select(g => new CustomerSourceSummary
            {
                Source = g.Key,
                Count = g.Count()
            })
            .OrderBy(x => x.Source)
            .ToList();
    }

    private static List<CustomerDuplicateGroup> FindDuplicatesByKey(
        List<Customer> customers,
        DuplicateMatchType matchType,
        Func<Customer, string> keySelector)
    {
        return customers
            .Select(c => new
            {
                Customer = c,
                MatchKey = keySelector(c)
            })
            .Where(x => !string.IsNullOrWhiteSpace(x.MatchKey))
            .GroupBy(x => x.MatchKey)
            .Where(g => g.Count() > 1)
            .Select(g => new CustomerDuplicateGroup
            {
                MatchType = matchType,
                MatchKey = g.Key,
                CustomerIds = g.Select(x => x.Customer.CustomerId).OrderBy(id => id).ToList(),
                CustomerNames = g.Select(x => x.Customer.FullName).Distinct().OrderBy(name => name).ToList()
            })
            .ToList();
    }

    private static bool IsValidForDuplicateProcessing(Customer customer)
    {
        return customer != null &&
               customer.CustomerId > 0 &&
               !string.IsNullOrWhiteSpace(customer.FullName) &&
               IsValidEmail(customer.Email) &&
               IsValidMobile(customer.MobileNumber) &&
               customer.DateOfBirth.HasValue;
    }

    private static bool IsValidEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
        {
            return false;
        }

        string normalizedEmail = NormalizeEmail(email);

        return normalizedEmail.Contains('@') &&
               normalizedEmail.Contains('.') &&
               normalizedEmail.IndexOf('@') > 0 &&
               normalizedEmail.LastIndexOf('.') > normalizedEmail.IndexOf('@') + 1;
    }

    private static bool IsValidMobile(string mobileNumber)
    {
        string normalizedMobile = NormalizeMobile(mobileNumber);

        return normalizedMobile.Length == 10 &&
               normalizedMobile.All(char.IsDigit) &&
               normalizedMobile[0] is '6' or '7' or '8' or '9';
    }

    private static string NormalizeEmail(string email)
    {
        return string.IsNullOrWhiteSpace(email)
            ? string.Empty
            : email.Trim().ToLowerInvariant();
    }

    private static string NormalizeMobile(string mobileNumber)
    {
        if (string.IsNullOrWhiteSpace(mobileNumber))
        {
            return string.Empty;
        }

        return new string(mobileNumber.Where(char.IsDigit).ToArray());
    }

    private static string CreateNameDobKey(Customer customer)
    {
        if (customer.DateOfBirth == null || string.IsNullOrWhiteSpace(customer.FullName))
        {
            return string.Empty;
        }

        string normalizedName = string.Join(
            " ",
            customer.FullName
                .Trim()
                .ToLowerInvariant()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries));

        return $"{normalizedName}|{customer.DateOfBirth.Value:yyyy-MM-dd}";
    }
}
