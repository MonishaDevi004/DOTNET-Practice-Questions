# Coding Challenge Question  
## Challenge 2: Customer Duplicate Detection

## Type

Code Completion / Bug Fixing / Business Logic Implementation

## Level

Intermediate

## Technology

C# .NET 8 Console Application

---

## Scenario

A customer onboarding system imports customer records from different sources such as website registration, mobile app registration, CRM import, and branch upload.

The business team noticed that the same customer is sometimes created more than once.

Duplicate records may happen because:

1. Email has different casing.
2. Email has leading or trailing spaces.
3. Mobile number is repeated.
4. Same person is imported with same full name and date of birth.
5. Some records are invalid and should be reported separately.

---

## Candidate Task

Implement the duplicate detection logic.

The program should:

1. Validate customer records.
2. Identify duplicate customers by normalized email.
3. Identify duplicate customers by normalized mobile number.
4. Identify duplicate customers by full name and date of birth.
5. Generate duplicate groups with duplicate reason.
6. Generate invalid customer record report.
7. Generate source-wise customer count.
8. Return unique customers by keeping the first valid occurrence.

---

## Sample Input

```json
[
  {
    "CustomerId": 1,
    "FullName": "Arun Kumar",
    "Email": "arun@test.com",
    "MobileNumber": "9876543210",
    "DateOfBirth": "1995-05-10",
    "Source": "Website"
  },
  {
    "CustomerId": 2,
    "FullName": "Priya Sharma",
    "Email": "priya@test.com",
    "MobileNumber": "9123456789",
    "DateOfBirth": "1996-07-12",
    "Source": "MobileApp"
  },
  {
    "CustomerId": 3,
    "FullName": "Arun Kumar",
    "Email": " ARUN@test.com ",
    "MobileNumber": "9876543210",
    "DateOfBirth": "1995-05-10",
    "Source": "CRM"
  }
]
```

---

## Expected Output

```text
Duplicate Groups:
Email - arun@test.com - CustomerIds: 1, 3
MobileNumber - 9876543210 - CustomerIds: 1, 3
NameAndDateOfBirth - arun kumar|1995-05-10 - CustomerIds: 1, 3

Invalid Records:
Records with missing name, invalid email, or invalid mobile number should be listed.

Unique Customers:
Only first valid occurrence should be retained.
```

---

## Technical Requirements

1. Implement the robust solution using C# best practice.
2. Ensure null, empty, invalid, duplicate, casing, and whitespace edge cases are handled.
3. Optimize for readability and execution time.
4. Use LINQ where it improves clarity.
5. Do not hardcode the output.
6. Do not remove the service layer.
7. Add NUnit test cases for all important scenarios.

---

## Edge Cases to Handle

1. Customer list is null.
2. Customer list is empty.
3. Email is empty.
4. Email has uppercase letters.
5. Email has extra spaces.
6. Mobile number has spaces or hyphens.
7. Mobile number is invalid.
8. Customer name is empty.
9. Date of birth is missing.
10. Same customer appears through different sources.
11. Two different customers share the same mobile number.
12. Duplicate grouping should not include single records.

---

## Main Concepts Tested

- C# classes and objects
- OOPS service design
- Collections
- LINQ GroupBy
- String normalization
- Data validation
- Generics through collections
- NUnit testing
