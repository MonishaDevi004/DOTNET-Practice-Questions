using CustomerDuplicateDetection.Models;
using CustomerDuplicateDetection.Services;
using NUnit.Framework;

namespace CustomerDuplicateDetection.Tests;

[TestFixture]
public class CustomerDuplicateDetectorTests
{
    private CustomerDuplicateDetector _detector = null!;

    [SetUp]
    public void Setup()
    {
        _detector = new CustomerDuplicateDetector();
    }

    [Test]
    public void FindDuplicateGroups_WhenEmailsDifferByCaseAndSpaces_ReturnsEmailDuplicate()
    {
        var customers = new List<Customer>
        {
            CreateCustomer(1, "Arun Kumar", "arun@test.com", "9876543210", new DateTime(1995, 5, 10), "Website"),
            CreateCustomer(2, "Arun K", " ARUN@test.com ", "9123456789", new DateTime(1994, 1, 1), "CRM")
        };

        var result = _detector.FindDuplicateGroups(customers);

        Assert.That(result.Any(x =>
            x.MatchType == DuplicateMatchType.Email &&
            x.MatchKey == "arun@test.com" &&
            x.CustomerIds.SequenceEqual(new[] { 1, 2 })), Is.True);
    }

    [Test]
    public void FindDuplicateGroups_WhenMobileContainsHyphen_ReturnsMobileDuplicate()
    {
        var customers = new List<Customer>
        {
            CreateCustomer(1, "Arun Kumar", "arun@test.com", "9876543210", new DateTime(1995, 5, 10), "Website"),
            CreateCustomer(2, "Arun K", "arun2@test.com", "98765-43210", new DateTime(1994, 1, 1), "CRM")
        };

        var result = _detector.FindDuplicateGroups(customers);

        Assert.That(result.Any(x =>
            x.MatchType == DuplicateMatchType.MobileNumber &&
            x.MatchKey == "9876543210"), Is.True);
    }

    [Test]
    public void FindDuplicateGroups_WhenSameNameAndDob_ReturnsNameDobDuplicate()
    {
        var customers = new List<Customer>
        {
            CreateCustomer(1, "Arun Kumar", "arun@test.com", "9876543210", new DateTime(1995, 5, 10), "Website"),
            CreateCustomer(2, " arun   kumar ", "arun2@test.com", "9123456789", new DateTime(1995, 5, 10), "CRM")
        };

        var result = _detector.FindDuplicateGroups(customers);

        Assert.That(result.Any(x =>
            x.MatchType == DuplicateMatchType.NameAndDateOfBirth &&
            x.MatchKey == "arun kumar|1995-05-10"), Is.True);
    }

    [Test]
    public void FindDuplicateGroups_WhenNoDuplicates_ReturnsEmptyList()
    {
        var customers = new List<Customer>
        {
            CreateCustomer(1, "Arun Kumar", "arun@test.com", "9876543210", new DateTime(1995, 5, 10), "Website"),
            CreateCustomer(2, "Priya Sharma", "priya@test.com", "9123456789", new DateTime(1996, 7, 12), "MobileApp")
        };

        var result = _detector.FindDuplicateGroups(customers);

        Assert.That(result, Is.Empty);
    }

    [Test]
    public void FindDuplicateGroups_WhenInputIsNull_ReturnsEmptyList()
    {
        var result = _detector.FindDuplicateGroups(null!);

        Assert.That(result, Is.Empty);
    }

    [Test]
    public void ValidateCustomers_WhenEmailIsInvalid_ReturnsValidationError()
    {
        var customers = new List<Customer>
        {
            CreateCustomer(1, "Arun Kumar", "invalid-email", "9876543210", new DateTime(1995, 5, 10), "Website")
        };

        var result = _detector.ValidateCustomers(customers);

        Assert.That(result, Has.Count.EqualTo(1));
        Assert.That(result[0].Reason, Does.Contain("Valid email is required"));
    }

    [Test]
    public void ValidateCustomers_WhenMobileIsInvalid_ReturnsValidationError()
    {
        var customers = new List<Customer>
        {
            CreateCustomer(1, "Arun Kumar", "arun@test.com", "12345", new DateTime(1995, 5, 10), "Website")
        };

        var result = _detector.ValidateCustomers(customers);

        Assert.That(result, Has.Count.EqualTo(1));
        Assert.That(result[0].Reason, Does.Contain("Valid 10 digit mobile number is required"));
    }

    [Test]
    public void ValidateCustomers_WhenRequiredFieldsMissing_ReturnsMultipleValidationErrors()
    {
        var customers = new List<Customer>
        {
            CreateCustomer(0, "", "", "", null, "")
        };

        var result = _detector.ValidateCustomers(customers);

        Assert.That(result, Has.Count.EqualTo(1));
        Assert.That(result[0].Reason, Does.Contain("Customer id must be greater than zero"));
        Assert.That(result[0].Reason, Does.Contain("Full name is required"));
        Assert.That(result[0].Reason, Does.Contain("Date of birth is required"));
        Assert.That(result[0].Reason, Does.Contain("Source is required"));
    }

    [Test]
    public void GetUniqueCustomers_WhenDuplicatesExist_ReturnsOnlyFirstValidOccurrence()
    {
        var customers = new List<Customer>
        {
            CreateCustomer(1, "Arun Kumar", "arun@test.com", "9876543210", new DateTime(1995, 5, 10), "Website"),
            CreateCustomer(2, "Arun Kumar", " ARUN@test.com ", "98765-43210", new DateTime(1995, 5, 10), "CRM"),
            CreateCustomer(3, "Priya Sharma", "priya@test.com", "9123456789", new DateTime(1996, 7, 12), "MobileApp")
        };

        var result = _detector.GetUniqueCustomers(customers);

        Assert.That(result, Has.Count.EqualTo(2));
        Assert.That(result.Select(x => x.CustomerId), Is.EqualTo(new[] { 1, 3 }));
    }

    [Test]
    public void GetSourceWiseSummary_ReturnsCorrectSourceCounts()
    {
        var customers = new List<Customer>
        {
            CreateCustomer(1, "Arun Kumar", "arun@test.com", "9876543210", new DateTime(1995, 5, 10), "Website"),
            CreateCustomer(2, "Priya Sharma", "priya@test.com", "9123456789", new DateTime(1996, 7, 12), "Website"),
            CreateCustomer(3, "Kumar", "kumar@test.com", "8123456789", new DateTime(1994, 1, 1), "CRM")
        };

        var result = _detector.GetSourceWiseSummary(customers);

        Assert.That(result, Has.Count.EqualTo(2));

        var website = result.First(x => x.Source == "Website");
        var crm = result.First(x => x.Source == "CRM");

        Assert.That(website.Count, Is.EqualTo(2));
        Assert.That(crm.Count, Is.EqualTo(1));
    }

    private static Customer CreateCustomer(
        int customerId,
        string fullName,
        string email,
        string mobileNumber,
        DateTime? dateOfBirth,
        string source)
    {
        return new Customer
        {
            CustomerId = customerId,
            FullName = fullName,
            Email = email,
            MobileNumber = mobileNumber,
            DateOfBirth = dateOfBirth,
            Source = source
        };
    }
}
