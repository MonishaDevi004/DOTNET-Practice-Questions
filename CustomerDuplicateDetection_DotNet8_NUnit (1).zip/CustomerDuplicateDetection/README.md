# Customer Duplicate Detection - .NET 8 Console Application

## Purpose

This is a ready-to-use intermediate-level C# .NET 8 coding challenge project for Karat-style .NET interview preparation.

The application detects duplicate customer records imported from multiple sources such as website registration, mobile app registration, CRM import, and branch upload.

## Technologies Used

- .NET SDK 8.0
- C# 12
- Console Application
- NUnit
- NUnit3TestAdapter
- Microsoft.NET.Test.Sdk

---

## Business Scenario

A customer onboarding system imports customer records from different channels.

Duplicate customer records may exist because of:

- Same email with different casing
- Same email with extra spaces
- Same mobile number
- Same name and date of birth
- Invalid or missing customer information
- Records coming from different import sources

The system must detect duplicate customer records and produce a clean duplicate report.

---

## Features Implemented

1. Duplicate detection by email
2. Duplicate detection by mobile number
3. Duplicate detection by full name and date of birth
4. Case-insensitive email comparison
5. Mobile number normalization
6. Invalid customer validation
7. Source-wise customer summary
8. Duplicate report generation
9. Unique customer extraction
10. NUnit test coverage

---

## Project Structure

```text
CustomerDuplicateDetection
│
├── CustomerDuplicateDetection.sln
├── README.md
├── QUESTION.md
├── RUN_COMMANDS.txt
│
├── src
│   └── CustomerDuplicateDetection
│       ├── CustomerDuplicateDetection.csproj
│       ├── Program.cs
│       ├── Models
│       │   ├── Customer.cs
│       │   ├── CustomerDuplicateGroup.cs
│       │   ├── CustomerSourceSummary.cs
│       │   ├── DuplicateMatchType.cs
│       │   └── InvalidCustomerRecord.cs
│       ├── Services
│       │   ├── ICustomerDuplicateDetector.cs
│       │   └── CustomerDuplicateDetector.cs
│       └── Data
│           └── SampleCustomerData.cs
│
└── tests
    └── CustomerDuplicateDetection.Tests
        ├── CustomerDuplicateDetection.Tests.csproj
        └── CustomerDuplicateDetectorTests.cs
```

---

## How to Run

Open terminal in the root folder and run:

```bash
dotnet restore
dotnet build
dotnet run --project src/CustomerDuplicateDetection/CustomerDuplicateDetection.csproj
```

---

## How to Run NUnit Tests

```bash
dotnet test
```

---

## Interview Evaluation Areas

| Skill | What to Observe |
|---|---|
| C# | Class design, null handling, string handling |
| OOPS | Models, service interface, clean separation |
| Collections | List processing, grouping, dictionary-like lookup |
| LINQ | GroupBy, Where, Select, OrderBy |
| Data Validation | Empty email, invalid mobile, missing name |
| Business Logic | Duplicate matching by multiple rules |
| Testing | NUnit test coverage for positive and edge cases |
| Readability | Clean method names and simple flow |
