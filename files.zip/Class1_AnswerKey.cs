// ============================================================
// .NET DEVELOPER ASSESSMENT — CLASS 1  *** ANSWER KEY ***
// Topic: Collections & Generics
// ============================================================
//
// BUGS SUMMARY (8 bugs total)
//
// BUG 1 — Wrong eviction index in Push()
//   Location : _items.RemoveAt(_items.Count - 1)
//   Problem  : Removes the LAST item (newest/top), not the oldest.
//              The oldest item in a List-backed stack is at index 0.
//   Fix      : _items.RemoveAt(0)
//
// BUG 2 — Wrong insertion point in Push()
//   Location : _items.Add(item)
//   Problem  : Add() appends to the END of the list, making the
//              newest item the hardest to reach. For a stack backed
//              by a List where index 0 = top, new items must be
//              inserted at index 0.
//   Fix      : _items.Insert(0, item)
//
// BUG 3 — Wrong index in Peek()
//   Location : return _items[0]  ← actually correct AFTER fixing BUG 2,
//              but wrong in the original code where Add() was used,
//              because Add() puts items at the end. Documented here for
//              clarity: once BUG 2 is fixed (Insert at 0), index 0 IS
//              the top, so Peek returning _items[0] becomes correct.
//              In the original buggy code the top was _items[Count-1].
//   Fix      : No change needed once BUG 2 is fixed.
//              (In isolation without fixing BUG 2: return _items[_items.Count - 1])
//
// BUG 4 — Wrong index in Pop() item retrieval
//   Location : T item = _items[0]
//   Problem  : Same root cause as BUG 3. With the original Add()-based
//              push, the top of the stack is at the last index, not 0.
//   Fix      : Resolved by fixing BUG 2. Once Insert(0) is used,
//              _items[0] correctly refers to the top.
//
// BUG 5 — Wrong index removed in Pop()
//   Location : _items.RemoveAt(0)
//   Problem  : Same root cause. With Add(), the top is at Count-1.
//   Fix      : Resolved by fixing BUG 2. With Insert(0), RemoveAt(0)
//              correctly removes the top item.
//
// NOTE: BUGs 3, 4, 5 are all symptoms of BUG 2. A sharp candidate
//       will spot that fixing Insert(0) resolves all three at once.
//       Credit should be given for identifying the root cause.
//
// BUG 6 — GetAll() returns internal list directly (reference leak)
//   Location : return _items
//   Problem  : Returns a direct reference to the internal list.
//              The caller can mutate _items from outside the class,
//              breaking encapsulation. Also, the list is in insertion
//              order (bottom→top with original code), not top→bottom.
//   Fix      : Return a reversed copy so order is top→bottom,
//              and the internal state is protected.
//              var copy = new List<T>(_items);
//              copy.Reverse();  ← only needed without BUG 2 fix
//              return copy;
//              With BUG 2 fixed (Insert at 0), _items is already
//              top→bottom, so: return new List<T>(_items);
//
// BUG 7 — KeyNotFoundException in GetEnrollmentCount()
//   Location : return _roster[course].Count
//   Problem  : Accessing a Dictionary with [] throws KeyNotFoundException
//              if the key doesn't exist. The spec says return 0 for
//              unknown courses.
//   Fix      : return _roster.TryGetValue(course, out var students)
//                  ? students.Count
//                  : 0;
//
// BUG 8 — Modifying collection while iterating in RemoveStudent()
//   Location : foreach (var course in _roster.Keys)
//   Problem  : Iterating over _roster.Keys while calling
//              _roster[course].Remove() is safe here for the inner
//              list, BUT if this were restructured to remove the key
//              itself it would throw. More critically — in .NET,
//              iterating Dictionary.Keys and modifying any Value list
//              that is itself a reference type is safe, but this is
//              a common misconception trap. The real subtle bug is:
//              if future refactoring removes empty courses from _roster
//              inside this loop it would break. The correct pattern is
//              to snapshot the keys first.
//   Fix      : foreach (var course in _roster.Keys.ToList())
//              {
//                  _roster[course].Remove(student);
//              }
//
// ============================================================

using System;
using System.Collections.Generic;
using System.Linq;

namespace Assessment.Answers
{
    public class BoundedStack<T>
    {
        private readonly List<T> _items;
        private readonly int _capacity;

        public int Count => _items.Count;

        public BoundedStack(int capacity)
        {
            if (capacity <= 0)
                throw new ArgumentException("Capacity must be greater than zero.");

            _capacity = capacity;
            _items = new List<T>(_capacity);
        }

        public void Push(T item)
        {
            if (_items.Count == _capacity)
                _items.RemoveAt(0);         // FIX BUG 1: evict oldest (index 0)

            _items.Insert(0, item);         // FIX BUG 2: insert at top (index 0)
        }

        public T Peek()
        {
            if (_items.Count == 0)
                throw new InvalidOperationException("Stack is empty.");

            return _items[0];               // Correct — index 0 is top after BUG 2 fix
        }

        public T Pop()
        {
            if (_items.Count == 0)
                throw new InvalidOperationException("Stack is empty.");

            T item = _items[0];             // Correct — index 0 is top after BUG 2 fix
            _items.RemoveAt(0);             // Correct — removes top after BUG 2 fix
            return item;
        }

        public bool Contains(T item)
        {
            return _items.Contains(item);
        }

        public IEnumerable<T> GetAll()
        {
            return new List<T>(_items);     // FIX BUG 6: return a copy, not the internal list
        }
    }


    public class CourseRoster
    {
        private readonly Dictionary<string, List<string>> _roster;

        public CourseRoster()
        {
            _roster = new Dictionary<string, List<string>>();
        }

        public void Enroll(string course, string student)
        {
            if (!_roster.ContainsKey(course))
                _roster[course] = new List<string>();

            if (!_roster[course].Contains(student))
                _roster[course].Add(student);
        }

        public int GetEnrollmentCount(string course)
        {
            // FIX BUG 7: safe lookup — returns 0 if course not found
            return _roster.TryGetValue(course, out var students)
                ? students.Count
                : 0;
        }

        public void TransferAll(string fromCourse, string toCourse)
        {
            if (!_roster.ContainsKey(fromCourse))
                return;

            if (!_roster.ContainsKey(toCourse))
                _roster[toCourse] = new List<string>();

            foreach (var student in _roster[fromCourse])
            {
                if (!_roster[toCourse].Contains(student))
                    _roster[toCourse].Add(student);
            }

            _roster[fromCourse].Clear();
        }

        public Dictionary<string, int> GetSummary()
        {
            var summary = new Dictionary<string, int>();
            foreach (var kvp in _roster)
                summary[kvp.Key] = kvp.Value.Count;
            return summary;
        }

        public void RemoveStudent(string student)
        {
            // FIX BUG 8: snapshot keys first to avoid mutation-during-iteration issues
            foreach (var course in _roster.Keys.ToList())
            {
                _roster[course].Remove(student);
            }
        }
    }


    class Program
    {
        static void Main()
        {
            Console.WriteLine("=== BoundedStack Tests ===");

            var stack = new BoundedStack<int>(3);
            stack.Push(1);
            stack.Push(2);
            stack.Push(3);
            stack.Push(4); // evicts 1 → stack top→bottom: [4, 3, 2]

            Console.WriteLine($"Peek (expected 4): {stack.Peek()}");
            Console.WriteLine($"Count (expected 3): {stack.Count}");

            var all = new List<int>(stack.GetAll());
            Console.WriteLine($"GetAll top→bottom (expected 4,3,2): {string.Join(",", all)}");

            Console.WriteLine($"Pop (expected 4): {stack.Pop()}");
            Console.WriteLine($"Pop (expected 3): {stack.Pop()}");
            Console.WriteLine($"Count after 2 pops (expected 1): {stack.Count}");

            Console.WriteLine("\n=== CourseRoster Tests ===");

            var roster = new CourseRoster();
            roster.Enroll("Math", "Alice");
            roster.Enroll("Math", "Bob");
            roster.Enroll("Math", "Alice");
            roster.Enroll("Science", "Alice");
            roster.Enroll("Science", "Charlie");

            Console.WriteLine($"Math count (expected 2): {roster.GetEnrollmentCount("Math")}");
            Console.WriteLine($"Physics count (expected 0): {roster.GetEnrollmentCount("Physics")}");

            roster.TransferAll("Math", "Science");
            Console.WriteLine($"Math after transfer (expected 0): {roster.GetEnrollmentCount("Math")}");
            Console.WriteLine($"Science after transfer (expected 3): {roster.GetEnrollmentCount("Science")}");

            roster.RemoveStudent("Alice");
            Console.WriteLine($"Science after removing Alice (expected 2): {roster.GetEnrollmentCount("Science")}");
        }
    }
}
