// ============================================================
// .NET DEVELOPER ASSESSMENT — CLASS 1 OF 7
// Topic  : Collections & Generics
// Level  : Medium–Hard
// Time   : 20 minutes
// ============================================================
//
// BACKGROUND
// ----------
// You are reviewing code written by a junior developer.
// The code compiles without errors but behaves incorrectly
// at runtime. Your job is to find and fix all the bugs.
//
// THE CODE
// --------
// This file contains two classes:
//
//   1. BoundedStack<T>
//      A generic stack with a fixed maximum capacity.
//      When the stack is full and a new item is pushed,
//      the OLDEST item is automatically evicted to make room.
//      Items should be accessible in LIFO order (last in, first out).
//
//   2. CourseRoster
//      Manages student enrollments across multiple courses.
//      Each course holds a unique list of student names.
//      Supports enrolling, transferring, and removing students.
//
// WHAT IS EXPECTED FROM YOU
// -------------------------
//   - Read the XML summary comments on each method carefully.
//     They describe the INTENDED behaviour.
//   - Identify every bug in the code.
//   - Fix each bug and add a brief inline comment explaining
//     what was wrong and why your fix is correct.
//   - Do NOT rewrite the classes from scratch. Fix only what
//     is broken.
//   - The Main() method at the bottom contains test cases with
//     expected output. All assertions should pass after your fixes.
//
// HINT: There are 8 bugs across both classes. Some bugs share
//       a common root cause — identifying that relationship
//       will demonstrate deeper understanding.
//
// ============================================================

using System;
using System.Collections.Generic;

namespace Assessment
{
    /// <summary>
    /// A generic stack with a fixed maximum capacity.
    /// When full, pushing a new item evicts the oldest item first.
    /// Items are returned in LIFO order (last in, first out).
    /// </summary>
    public class BoundedStack<T>
    {
        private readonly List<T> _items;
        private readonly int _capacity;

        public int Count => _items.Count;

        public BoundedStack(int capacity)
        {
            if (capacity <= 0)
                throw new ArgumentException("Capacity must be greater than zero.");

            _capacity = capacity;
            _items = new List<T>(_capacity);
        }

        /// <summary>
        /// Pushes an item onto the top of the stack.
        /// If the stack is at capacity, the oldest item is evicted before pushing.
        /// </summary>
        public void Push(T item)
        {
            if (_items.Count == _capacity)
                _items.RemoveAt(_items.Count - 1); // BUG 1

            _items.Add(item); // BUG 2
        }

        /// <summary>
        /// Returns the top item without removing it.
        /// Throws InvalidOperationException if the stack is empty.
        /// </summary>
        public T Peek()
        {
            if (_items.Count == 0)
                throw new InvalidOperationException("Stack is empty.");

            return _items[0]; // BUG 3
        }

        /// <summary>
        /// Removes and returns the top item.
        /// Throws InvalidOperationException if the stack is empty.
        /// </summary>
        public T Pop()
        {
            if (_items.Count == 0)
                throw new InvalidOperationException("Stack is empty.");

            T item = _items[0]; // BUG 4
            _items.RemoveAt(0); // BUG 5
            return item;
        }

        /// <summary>
        /// Returns true if the item exists anywhere in the stack.
        /// </summary>
        public bool Contains(T item)
        {
            return _items.Contains(item);
        }

        /// <summary>
        /// Returns all items ordered from top (most recent) to bottom (oldest).
        /// </summary>
        public IEnumerable<T> GetAll()
        {
            return _items; // BUG 6
        }
    }


    /// <summary>
    /// Manages student enrollments across multiple courses.
    /// Each course maintains a unique list of enrolled student names.
    /// </summary>
    public class CourseRoster
    {
        private readonly Dictionary<string, List<string>> _roster;

        public CourseRoster()
        {
            _roster = new Dictionary<string, List<string>>();
        }

        /// <summary>
        /// Enrolls a student in a course.
        /// If the student is already enrolled, the request is ignored.
        /// If the course does not exist, it is created automatically.
        /// </summary>
        public void Enroll(string course, string student)
        {
            if (!_roster.ContainsKey(course))
                _roster[course] = new List<string>();

            if (!_roster[course].Contains(student))
                _roster[course].Add(student);
        }

        /// <summary>
        /// Returns the number of students enrolled in a course.
        /// Returns 0 if the course does not exist.
        /// </summary>
        public int GetEnrollmentCount(string course)
        {
            return _roster[course].Count; // BUG 7
        }

        /// <summary>
        /// Transfers all students from one course to another.
        /// Duplicate enrollments in the destination are ignored.
        /// The source course will be empty after the transfer.
        /// </summary>
        public void TransferAll(string fromCourse, string toCourse)
        {
            if (!_roster.ContainsKey(fromCourse))
                return;

            if (!_roster.ContainsKey(toCourse))
                _roster[toCourse] = new List<string>();

            foreach (var student in _roster[fromCourse])
            {
                if (!_roster[toCourse].Contains(student))
                    _roster[toCourse].Add(student);
            }

            _roster[fromCourse].Clear();
        }

        /// <summary>
        /// Returns a snapshot dictionary of course names to their student counts.
        /// </summary>
        public Dictionary<string, int> GetSummary()
        {
            var summary = new Dictionary<string, int>();
            foreach (var kvp in _roster)
                summary[kvp.Key] = kvp.Value.Count;
            return summary;
        }

        /// <summary>
        /// Removes a student from every course they are enrolled in.
        /// </summary>
        public void RemoveStudent(string student)
        {
            foreach (var course in _roster.Keys) // BUG 8
            {
                _roster[course].Remove(student);
            }
        }
    }


    class Program
    {
        static void Main()
        {
            // --- BoundedStack Tests ---
            Console.WriteLine("=== BoundedStack Tests ===");

            var stack = new BoundedStack<int>(3);
            stack.Push(1);
            stack.Push(2);
            stack.Push(3);

            // Stack is full. Push 4 — oldest item (1) is evicted.
            // Stack top→bottom should be: 4, 3, 2
            stack.Push(4);

            Console.WriteLine($"Peek       (expected 4):     {stack.Peek()}");
            Console.WriteLine($"Count      (expected 3):     {stack.Count}");

            var all = new List<int>(stack.GetAll());
            Console.WriteLine($"GetAll     (expected 4,3,2): {string.Join(",", all)}");

            Console.WriteLine($"Pop        (expected 4):     {stack.Pop()}");
            Console.WriteLine($"Pop        (expected 3):     {stack.Pop()}");
            Console.WriteLine($"Count      (expected 1):     {stack.Count}");

            // --- CourseRoster Tests ---
            Console.WriteLine("\n=== CourseRoster Tests ===");

            var roster = new CourseRoster();
            roster.Enroll("Math", "Alice");
            roster.Enroll("Math", "Bob");
            roster.Enroll("Math", "Alice"); // duplicate — should be ignored
            roster.Enroll("Science", "Alice");
            roster.Enroll("Science", "Charlie");

            Console.WriteLine($"Math count     (expected 2): {roster.GetEnrollmentCount("Math")}");
            Console.WriteLine($"Physics count  (expected 0): {roster.GetEnrollmentCount("Physics")}");

            roster.TransferAll("Math", "Science");
            Console.WriteLine($"Math after transfer    (expected 0): {roster.GetEnrollmentCount("Math")}");
            Console.WriteLine($"Science after transfer (expected 3): {roster.GetEnrollmentCount("Science")}");

            roster.RemoveStudent("Alice");
            Console.WriteLine($"Science after removing Alice (expected 2): {roster.GetEnrollmentCount("Science")}");
        }
    }
}
