# Citi Karat Prep — Question 2: Customer Record Deduplication (.NET 10)

A ready-to-run **.NET 10** console project for the second Karat-style code
completion question (Citi .NET Associate prep).

## Project layout
```
CitiKaratPrep_Q2/
├── CitiKaratPrep_Q2.csproj       # targets net10.0
├── Program.cs                    # starter code — candidate completes DeduplicateCustomers()
└── docs/
    ├── Citi_Karat_CSharp_Completion_CustomerDeduplication.md           # problem statement, rubric, follow-up
    └── Citi_Karat_CSharp_Completion_CustomerDeduplication_Solution.txt  # answer key (file name matches the
                                                                          # problem statement, kept as .txt so
                                                                          # it never compiles)
```

## Requirements
- [.NET 10 SDK](https://dotnet.microsoft.com/download) installed (`dotnet --version` → `10.x`)

## How to run
```bash
cd CitiKaratPrep_Q2
dotnet run
```

It builds and runs out of the box but prints a placeholder message until
`DeduplicateCustomers` is implemented.

## How to use in a mock interview
1. Read the problem statement from
   `docs/Citi_Karat_CSharp_Completion_CustomerDeduplication.md` to the candidate
   (don't hand them this file directly — it has the rubric and hints).
2. Give them only `Program.cs`.
3. Have them implement `DeduplicateCustomers`, narrating their approach —
   watch specifically for whether they catch the **transitive merge** edge
   case (Ben Lee / Benjamin Lee) before or after writing code.
4. Verify with `dotnet run` against the expected output in the question doc.
5. Use the optional follow-up (record count per merged group) as a
   finish-early extension.
6. Score against the rubric table, then compare their solution to
   `docs/Citi_Karat_CSharp_Completion_CustomerDeduplication_Solution.txt`.
