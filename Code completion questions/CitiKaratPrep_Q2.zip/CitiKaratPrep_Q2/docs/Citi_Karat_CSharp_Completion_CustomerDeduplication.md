# Citi (Karat) – C# Console Code Completion Question 2
**Topic:** Customer Record Deduplication
**Level:** Intermediate (.NET Associate) | **Format:** Karat-style code completion | **Time box:** 15–20 min

---

## How to run this in a mock session
Same format as Question 1: give the candidate the **"Starter Code"** section only. They complete one missing method while narrating their approach. This mirrors the real Citi Karat report of a "phone-book / contact matching" style coding question — duplicate/lookup logic over a list of records, not classic DSA.

---

## Problem Statement (read this to the student)

> Citi's onboarding system has accumulated duplicate customer records because the same person sometimes signs up more than once with slightly different names. You're given a list of `CustomerRecord` objects, each with a `Name`, `Email`, and `Phone`.
>
> Complete the method `DeduplicateCustomers` so that it merges records into a single entry **whenever two records share the same `Email` OR the same `Phone`** (case-insensitive for email). When merging:
> - Keep the **first** `Name` encountered for that group.
> - Combine all distinct, non-empty emails for that person into one comma-separated string.
> - Combine all distinct, non-empty phone numbers for that person into one comma-separated string.
>
> Return the deduplicated list, sorted by `Name` ascending. If the input list is null or empty, return an empty list.

### Sample Input
```
[
  { Name: "Asha Rao",   Email: "asha@citi.com",   Phone: "9990001111" },
  { Name: "A. Rao",     Email: "asha@citi.com",   Phone: "9990002222" },
  { Name: "Ben Lee",    Email: "ben@citi.com",    Phone: "8881112222" },
  { Name: "Benjamin Lee", Email: "benjamin@citi.com", Phone: "8881112222" },
  { Name: "Cara Diaz",  Email: "cara@citi.com",   Phone: "7773334444" }
]
```

### Expected Output
```
Asha Rao -> Emails: asha@citi.com, Phones: 9990001111, 9990002222
Ben Lee -> Emails: ben@citi.com, benjamin@citi.com, Phones: 8881112222
Cara Diaz -> Emails: cara@citi.com, Phones: 7773334444
```

> Note: "Asha Rao" and "A. Rao" merge because of shared email. "Ben Lee" and "Benjamin Lee" merge because of shared phone, even though their emails differ — both emails get combined.

### Constraints / Edge Cases to probe (ask the candidate to call these out)
- A record can link two otherwise-unconnected records together (transitive merge: if A matches B by email, and B matches C by phone, should A and C end up in the same group?) — **good clarifying question**; for this exercise, treat it as transitive (use a Union-Find / grouping approach, not a single-pass dictionary lookup).
- Null or empty `Email`/`Phone` fields should never be used as a merge key.
- Case-insensitive email comparison ("Asha@Citi.com" should match "asha@citi.com").
- Empty/null input list → empty output.
- Output sorted by the kept `Name`.

---

## Starter Code (give this to the candidate)

```csharp
using System;
using System.Collections.Generic;
using System.Linq;

namespace CitiCustomerDedup
{
    public class CustomerRecord
    {
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
    }

    public class MergedCustomer
    {
        public string Name { get; set; } = string.Empty;
        public List<string> Emails { get; set; } = new List<string>();
        public List<string> Phones { get; set; } = new List<string>();
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<CustomerRecord> records = new List<CustomerRecord>
            {
                new CustomerRecord { Name = "Asha Rao",     Email = "asha@citi.com",     Phone = "9990001111" },
                new CustomerRecord { Name = "A. Rao",       Email = "asha@citi.com",     Phone = "9990002222" },
                new CustomerRecord { Name = "Ben Lee",      Email = "ben@citi.com",      Phone = "8881112222" },
                new CustomerRecord { Name = "Benjamin Lee", Email = "benjamin@citi.com", Phone = "8881112222" },
                new CustomerRecord { Name = "Cara Diaz",    Email = "cara@citi.com",     Phone = "7773334444" }
            };

            List<MergedCustomer> result = DeduplicateCustomers(records);

            if (result.Count == 0)
            {
                Console.WriteLine("(No output yet — complete the DeduplicateCustomers method in Program.cs)");
            }

            foreach (var c in result)
            {
                Console.WriteLine($"{c.Name} -> Emails: {string.Join(", ", c.Emails)}, " +
                                   $"Phones: {string.Join(", ", c.Phones)}");
            }
        }

        // ---------------------------------------------------------------------
        // TODO (Candidate task):
        // Merge records that share the same Email (case-insensitive) OR the
        // same Phone, transitively. Keep the first Name seen for each merged
        // group. Combine distinct, non-empty emails and phones. Ignore null
        // or empty Email/Phone when matching. Return list sorted by Name.
        // If input is null or empty, return an empty list.
        // ---------------------------------------------------------------------
        static List<MergedCustomer> DeduplicateCustomers(List<CustomerRecord> records)
        {
            // your code here
            return new List<MergedCustomer>();
        }
    }
}
```

---

## What to score the candidate on (Karat-style rubric)

| Dimension | Look for |
|---|---|
| **Clarifying questions** | Did they catch the transitive-merge subtlety (Ben Lee / Benjamin Lee case) before coding? |
| **Correctness** | Matches expected output, including the transitive merge case |
| **Approach** | Recognizes this as a "grouping by shared key" / graph-connectivity problem — Dictionary-of-sets or simple Union-Find are both acceptable at this level |
| **Communication** | Talks through the transitive-merge edge case out loud, doesn't just hard-code for the sample |
| **Iteration** | Gets a working version for simple (non-transitive) duplicates first, then extends to handle the chained case |
| **Edge case handling** | Null/empty fields, null/empty input list, case-insensitive email |
| **Code quality** | Clear naming, no duplicated merge logic copy-pasted for email vs phone |

---

## Optional follow-up (if they finish early)
> "Now also report, for each merged customer, **how many original records** were combined into it." — tests whether they can extend their grouping structure to carry an extra piece of state without a full rewrite.
