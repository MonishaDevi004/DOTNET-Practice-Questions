using System;
using System.Collections.Generic;
using System.Linq;

namespace CitiCustomerDedup
{
    public class CustomerRecord
    {
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
    }

    public class MergedCustomer
    {
        public string Name { get; set; } = string.Empty;
        public List<string> Emails { get; set; } = new List<string>();
        public List<string> Phones { get; set; } = new List<string>();
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<CustomerRecord> records = new List<CustomerRecord>
            {
                new CustomerRecord { Name = "Asha Rao",     Email = "asha@citi.com",     Phone = "9990001111" },
                new CustomerRecord { Name = "A. Rao",       Email = "asha@citi.com",     Phone = "9990002222" },
                new CustomerRecord { Name = "Ben Lee",      Email = "ben@citi.com",      Phone = "8881112222" },
                new CustomerRecord { Name = "Benjamin Lee", Email = "benjamin@citi.com", Phone = "8881112222" },
                new CustomerRecord { Name = "Cara Diaz",    Email = "cara@citi.com",     Phone = "7773334444" }
            };

            List<MergedCustomer> result = DeduplicateCustomers(records);

            if (result.Count == 0)
            {
                Console.WriteLine("(No output yet — complete the DeduplicateCustomers method in Program.cs)");
            }

            foreach (var c in result)
            {
                Console.WriteLine($"{c.Name} -> Emails: {string.Join(", ", c.Emails)}, " +
                                   $"Phones: {string.Join(", ", c.Phones)}");
            }
        }

        // ---------------------------------------------------------------------
        // TODO (Candidate task):
        // Merge records that share the same Email (case-insensitive) OR the
        // same Phone, transitively. Keep the first Name seen for each merged
        // group. Combine distinct, non-empty emails and phones. Ignore null
        // or empty Email/Phone when matching. Return list sorted by Name.
        // If input is null or empty, return an empty list.
        // ---------------------------------------------------------------------
        static List<MergedCustomer> DeduplicateCustomers(List<CustomerRecord> records)
        {
            // your code here
            return new List<MergedCustomer>();
        }
    }
}
