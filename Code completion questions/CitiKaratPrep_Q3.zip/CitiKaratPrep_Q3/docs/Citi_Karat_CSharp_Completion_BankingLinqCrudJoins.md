# Citi (Karat) – C# Console Code Completion Question 3
**Topic:** Banking Domain — LINQ Joins, Projection, Selection + In-Memory CRUD
**Level:** Intermediate–Advanced (.NET Associate, stretch question) | **Format:** Karat-style code completion | **Time box:** 25–30 min

---

## How to run this in a mock session
This is a **multi-part** completion question — deliberately heavier than Q1/Q2. Real Karat rounds sometimes give a stronger candidate one larger, multi-method problem instead of two short ones, especially once they've shown they're fast. Give the candidate only the **"Starter Code"** section. There are **5 TODO methods**; let them choose their own order, but expect them to at least attempt all 5 in the time box. Each method isolates a different LINQ skill plus one CRUD operation.

---

## Problem Statement (read this to the student)

> You're building a small in-memory banking service for Citi's branch system. Three entities exist: `Customer`, `Account`, and `Transaction`. An `Account` belongs to one `Customer` (via `CustomerId`), and a `Transaction` belongs to one `Account` (via `AccountId`).
>
> Complete the 5 methods in `BankingService` below. Each one targets a specific LINQ/CRUD skill:
>
> 1. **`AddAccount`** (Create) — Add a new account for an existing customer. Throw `InvalidOperationException` if the `CustomerId` doesn't exist.
> 2. **`GetCustomerAccountSummary`** (Join + Projection) — Inner-join `Customers` and `Accounts`, project into a `CustomerAccountSummary` (CustomerName, AccountType, Balance), sorted by `CustomerName` then `Balance` descending.
> 3. **`UpdateAccountBalance`** (Update) — Find the account by `AccountId` and add `amount` to its balance (amount can be negative for a debit). Return `false` if the account doesn't exist or if the update would make the balance negative; otherwise apply it and return `true`.
> 4. **`DeleteAccount`** (Delete) — Remove the account only if its balance is exactly 0. Return `false` (and don't delete) if the account doesn't exist or has a non-zero balance.
> 5. **`GetCustomersWithoutAccounts`** (Left/Outer Join via `GroupJoin`) — Return the names of all customers who currently have **zero** accounts, sorted alphabetically.

### Seed Data (already in the starter code)
```
Customers: C1-Asha Rao(Chennai), C2-Ben Lee(Singapore), C3-Cara Diaz(Madrid)
Accounts:  A1(C1, Savings, 5000), A2(C1, Current, 1200), A3(C2, Savings, 0)
Transactions: (not required for these 5 methods, included for realism/extension)
```

### Expected behavior once implemented
```
-- GetCustomerAccountSummary --
Asha Rao -> Savings: 5000
Asha Rao -> Current: 1200
Ben Lee -> Savings: 0

-- UpdateAccountBalance(A2, -200) --
true   (Current account balance becomes 1000)

-- UpdateAccountBalance(A2, -5000) --
false  (would go negative, rejected, balance unchanged)

-- DeleteAccount(A3) --
true   (balance was 0)

-- DeleteAccount(A1) --
false  (balance is 5000, not 0)

-- GetCustomersWithoutAccounts --
Cara Diaz
```

### Constraints / Edge Cases to probe
- `AddAccount` for a non-existent `CustomerId` → must throw, not silently fail
- `UpdateAccountBalance` must not allow the balance to go negative
- `DeleteAccount` must be a no-op (return false) for non-zero balance or unknown id
- `GetCustomersWithoutAccounts` must use a **left/outer join pattern** (`GroupJoin` + `DefaultIfEmpty`, or `Where(... !Any(...))`) — not just filtering accounts, since a customer with zero accounts won't appear at all in an inner join
- All projections should return new DTO objects, not the raw entity references

---

## Starter Code (give this to the candidate)

```csharp
using System;
using System.Collections.Generic;
using System.Linq;

namespace CitiBankingLinq
{
    public class Customer
    {
        public string CustomerId { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
    }

    public class Account
    {
        public string AccountId { get; set; } = string.Empty;
        public string CustomerId { get; set; } = string.Empty;
        public string AccountType { get; set; } = string.Empty; // "Savings" or "Current"
        public decimal Balance { get; set; }
    }

    public class Transaction
    {
        public string TransactionId { get; set; } = string.Empty;
        public string AccountId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
        public string Type { get; set; } = string.Empty; // "Credit" or "Debit"
    }

    public class CustomerAccountSummary
    {
        public string CustomerName { get; set; } = string.Empty;
        public string AccountType { get; set; } = string.Empty;
        public decimal Balance { get; set; }
    }

    public class BankingService
    {
        private readonly List<Customer> _customers = new List<Customer>
        {
            new Customer { CustomerId = "C1", Name = "Asha Rao", City = "Chennai" },
            new Customer { CustomerId = "C2", Name = "Ben Lee",  City = "Singapore" },
            new Customer { CustomerId = "C3", Name = "Cara Diaz", City = "Madrid" }
        };

        private readonly List<Account> _accounts = new List<Account>
        {
            new Account { AccountId = "A1", CustomerId = "C1", AccountType = "Savings", Balance = 5000 },
            new Account { AccountId = "A2", CustomerId = "C1", AccountType = "Current", Balance = 1200 },
            new Account { AccountId = "A3", CustomerId = "C2", AccountType = "Savings", Balance = 0 }
        };

        private readonly List<Transaction> _transactions = new List<Transaction>();

        // ---------------------------------------------------------------------
        // TODO 1 (Create): Add a new account for an existing customer.
        // Throw InvalidOperationException if CustomerId doesn't exist.
        // ---------------------------------------------------------------------
        public void AddAccount(Account account)
        {
            // your code here
        }

        // ---------------------------------------------------------------------
        // TODO 2 (Join + Projection): Inner-join Customers and Accounts.
        // Project into CustomerAccountSummary. Sort by CustomerName asc,
        // then Balance desc.
        // ---------------------------------------------------------------------
        public List<CustomerAccountSummary> GetCustomerAccountSummary()
        {
            // your code here
            return new List<CustomerAccountSummary>();
        }

        // ---------------------------------------------------------------------
        // TODO 3 (Update): Add `amount` to the account's balance (amount may
        // be negative). Return false without changing anything if the account
        // doesn't exist or if applying amount would make balance negative.
        // ---------------------------------------------------------------------
        public bool UpdateAccountBalance(string accountId, decimal amount)
        {
            // your code here
            return false;
        }

        // ---------------------------------------------------------------------
        // TODO 4 (Delete): Remove the account only if its balance is exactly 0.
        // Return false (no deletion) if not found or balance != 0.
        // ---------------------------------------------------------------------
        public bool DeleteAccount(string accountId)
        {
            // your code here
            return false;
        }

        // ---------------------------------------------------------------------
        // TODO 5 (Left/Outer Join via GroupJoin): Return names of customers
        // who currently have zero accounts, sorted alphabetically.
        // ---------------------------------------------------------------------
        public List<string> GetCustomersWithoutAccounts()
        {
            // your code here
            return new List<string>();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var service = new BankingService();

            Console.WriteLine("-- GetCustomerAccountSummary --");
            foreach (var s in service.GetCustomerAccountSummary())
                Console.WriteLine($"{s.CustomerName} -> {s.AccountType}: {s.Balance}");

            Console.WriteLine();
            Console.WriteLine("-- UpdateAccountBalance(A2, -200) --");
            Console.WriteLine(service.UpdateAccountBalance("A2", -200));

            Console.WriteLine();
            Console.WriteLine("-- UpdateAccountBalance(A2, -5000) --");
            Console.WriteLine(service.UpdateAccountBalance("A2", -5000));

            Console.WriteLine();
            Console.WriteLine("-- DeleteAccount(A3) --");
            Console.WriteLine(service.DeleteAccount("A3"));

            Console.WriteLine();
            Console.WriteLine("-- DeleteAccount(A1) --");
            Console.WriteLine(service.DeleteAccount("A1"));

            Console.WriteLine();
            Console.WriteLine("-- GetCustomersWithoutAccounts --");
            foreach (var name in service.GetCustomersWithoutAccounts())
                Console.WriteLine(name);
        }
    }
}
```

---

## What to score the candidate on (Karat-style rubric)

| Dimension | Look for |
|---|---|
| **Join correctness** | Uses `Join` (inner) correctly in TODO 2; recognizes TODO 5 needs an **outer/left join pattern** (`GroupJoin` + `DefaultIfEmpty`, or equivalent `!Any()` filter) rather than a plain inner join |
| **Projection discipline** | Returns new DTOs (`CustomerAccountSummary`), doesn't leak raw entities |
| **CRUD correctness** | Create validates FK existence; Update enforces the non-negative rule; Delete enforces the zero-balance rule; none of them silently corrupt state on invalid input |
| **LINQ fluency** | Comfortable mixing method syntax (`.Where`, `.Select`, `.OrderBy`, `.ThenByDescending`) and knows when `FirstOrDefault` vs `Single` vs `Any` is appropriate |
| **Clarifying questions** | Asks what should happen on duplicate `AccountId` in `AddAccount`, or whether `UpdateAccountBalance` should allow balance to hit exactly 0 |
| **Communication & iteration** | Tackles methods in a sensible order (simpler CRUD first, harder outer-join last), narrates trade-offs out loud |
| **Code quality** | No duplicated lookup logic across methods; mutations are localized and clear |

---

## Optional follow-up (if they finish early)
> "Add a `GetAccountsWithRecentActivity(int days)` method that **joins Accounts to Transactions**, returning accounts with at least one transaction in the last N days — project to include `AccountId`, `CustomerName`, and `LastTransactionDate`." This forces a second join (Account→Transaction) layered on top of the first (Customer→Account), and tests whether they can compose joins rather than just repeat the same pattern.
