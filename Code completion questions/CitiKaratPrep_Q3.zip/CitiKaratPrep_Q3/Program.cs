using System;
using System.Collections.Generic;
using System.Linq;

namespace CitiBankingLinq
{
    public class Customer
    {
        public string CustomerId { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
    }

    public class Account
    {
        public string AccountId { get; set; } = string.Empty;
        public string CustomerId { get; set; } = string.Empty;
        public string AccountType { get; set; } = string.Empty; // "Savings" or "Current"
        public decimal Balance { get; set; }
    }

    public class Transaction
    {
        public string TransactionId { get; set; } = string.Empty;
        public string AccountId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
        public string Type { get; set; } = string.Empty; // "Credit" or "Debit"
    }

    public class CustomerAccountSummary
    {
        public string CustomerName { get; set; } = string.Empty;
        public string AccountType { get; set; } = string.Empty;
        public decimal Balance { get; set; }
    }

    public class BankingService
    {
        private readonly List<Customer> _customers = new List<Customer>
        {
            new Customer { CustomerId = "C1", Name = "Asha Rao", City = "Chennai" },
            new Customer { CustomerId = "C2", Name = "Ben Lee",  City = "Singapore" },
            new Customer { CustomerId = "C3", Name = "Cara Diaz", City = "Madrid" }
        };

        private readonly List<Account> _accounts = new List<Account>
        {
            new Account { AccountId = "A1", CustomerId = "C1", AccountType = "Savings", Balance = 5000 },
            new Account { AccountId = "A2", CustomerId = "C1", AccountType = "Current", Balance = 1200 },
            new Account { AccountId = "A3", CustomerId = "C2", AccountType = "Savings", Balance = 0 }
        };

        private readonly List<Transaction> _transactions = new List<Transaction>();

        // ---------------------------------------------------------------------
        // TODO 1 (Create): Add a new account for an existing customer.
        // Throw InvalidOperationException if CustomerId doesn't exist.
        // ---------------------------------------------------------------------
        public void AddAccount(Account account)
        {
            // your code here
        }

        // ---------------------------------------------------------------------
        // TODO 2 (Join + Projection): Inner-join Customers and Accounts.
        // Project into CustomerAccountSummary. Sort by CustomerName asc,
        // then Balance desc.
        // ---------------------------------------------------------------------
        public List<CustomerAccountSummary> GetCustomerAccountSummary()
        {
            // your code here
            return new List<CustomerAccountSummary>();
        }

        // ---------------------------------------------------------------------
        // TODO 3 (Update): Add `amount` to the account's balance (amount may
        // be negative). Return false without changing anything if the account
        // doesn't exist or if applying amount would make balance negative.
        // ---------------------------------------------------------------------
        public bool UpdateAccountBalance(string accountId, decimal amount)
        {
            // your code here
            return false;
        }

        // ---------------------------------------------------------------------
        // TODO 4 (Delete): Remove the account only if its balance is exactly 0.
        // Return false (no deletion) if not found or balance != 0.
        // ---------------------------------------------------------------------
        public bool DeleteAccount(string accountId)
        {
            // your code here
            return false;
        }

        // ---------------------------------------------------------------------
        // TODO 5 (Left/Outer Join via GroupJoin): Return names of customers
        // who currently have zero accounts, sorted alphabetically.
        // ---------------------------------------------------------------------
        public List<string> GetCustomersWithoutAccounts()
        {
            // your code here
            return new List<string>();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var service = new BankingService();

            Console.WriteLine("-- GetCustomerAccountSummary --");
            foreach (var s in service.GetCustomerAccountSummary())
                Console.WriteLine($"{s.CustomerName} -> {s.AccountType}: {s.Balance}");

            Console.WriteLine();
            Console.WriteLine("-- UpdateAccountBalance(A2, -200) --");
            Console.WriteLine(service.UpdateAccountBalance("A2", -200));

            Console.WriteLine();
            Console.WriteLine("-- UpdateAccountBalance(A2, -5000) --");
            Console.WriteLine(service.UpdateAccountBalance("A2", -5000));

            Console.WriteLine();
            Console.WriteLine("-- DeleteAccount(A3) --");
            Console.WriteLine(service.DeleteAccount("A3"));

            Console.WriteLine();
            Console.WriteLine("-- DeleteAccount(A1) --");
            Console.WriteLine(service.DeleteAccount("A1"));

            Console.WriteLine();
            Console.WriteLine("-- GetCustomersWithoutAccounts --");
            foreach (var name in service.GetCustomersWithoutAccounts())
                Console.WriteLine(name);
        }
    }
}
