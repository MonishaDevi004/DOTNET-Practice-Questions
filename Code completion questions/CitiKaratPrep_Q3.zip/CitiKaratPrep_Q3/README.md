# Citi Karat Prep — Question 3: Banking LINQ Joins, Projection, Selection + CRUD (.NET 10)

A ready-to-run **.NET 10** console project for the third, higher-complexity
Karat-style code completion question (Citi .NET Associate prep — stretch level).

This question is intentionally heavier than Q1/Q2: 5 TODO methods covering
**Create / Read (Join+Project) / Update / Delete / Outer Join**, in one
in-memory `BankingService`.

## Project layout
```
CitiKaratPrep_Q3/
├── CitiKaratPrep_Q3.csproj       # targets net10.0
├── Program.cs                    # starter code — 5 TODO methods to complete
└── docs/
    ├── Citi_Karat_CSharp_Completion_BankingLinqCrudJoins.md            # problem statement, rubric, follow-up
    └── Citi_Karat_CSharp_Completion_BankingLinqCrudJoins_Solution.txt   # answer key (file name matches the
                                                                          # problem statement, kept as .txt so
                                                                          # it never compiles)
```

## Requirements
- [.NET 10 SDK](https://dotnet.microsoft.com/download) installed (`dotnet --version` → `10.x`)

## How to run
```bash
cd CitiKaratPrep_Q3
dotnet run
```

Builds and runs out of the box. Until the 5 TODOs are implemented, you'll see
empty lists and `False` returned everywhere — that's expected.

## What this question covers
| TODO | Skill |
|---|---|
| 1. `AddAccount` | Create + FK validation |
| 2. `GetCustomerAccountSummary` | Inner `Join` + projection into a DTO + multi-key sort |
| 3. `UpdateAccountBalance` | Update with a business-rule guard (no negative balance) |
| 4. `DeleteAccount` | Delete with a business-rule guard (zero balance only) |
| 5. `GetCustomersWithoutAccounts` | Left/outer join via `GroupJoin` + `DefaultIfEmpty` pattern |

## How to use in a mock interview
1. Read the problem statement from
   `docs/Citi_Karat_CSharp_Completion_BankingLinqCrudJoins.md` to the candidate.
2. Give them only `Program.cs`. Let them pick their own order across the 5 methods.
3. Time-box to 25–30 minutes — this is meant to feel like a "stretch" question.
4. Watch specifically for whether they reach for `GroupJoin`/outer-join logic
   on TODO 5 instead of an inner join (a very common mistake at this level).
5. Verify with `dotnet run` against the expected output in the question doc.
6. Use the optional follow-up (`GetAccountsWithRecentActivity`) if they finish
   early — it composes a second join on top of the first.
7. Score against the rubric table, then compare against
   `docs/Citi_Karat_CSharp_Completion_BankingLinqCrudJoins_Solution.txt`.
