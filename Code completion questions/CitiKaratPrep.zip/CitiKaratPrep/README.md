# Citi Karat Prep — C# Console Code Completion App

A ready-to-run **.NET 10** console project built around the Karat-style code
completion question used for Citi .NET Associate interview prep.

## Project layout
```
CitiKaratPrep/
├── CitiKaratPrep.csproj          # targets net10.0
├── Program.cs                    # starter code — candidate completes GetCustomerSummary()
└── docs/
    ├── Citi_Karat_CSharp_Completion_Question.md   # full problem statement, rubric, follow-ups
    └── ReferenceSolution_TrainerOnly.txt           # answer key (kept as .txt so it never compiles)
```

## Requirements
- [.NET 10 SDK](https://dotnet.microsoft.com/download) installed
  (`dotnet --version` should report a `10.x` SDK)

## How to run
```bash
cd CitiKaratPrep
dotnet run
```

Out of the box it builds and runs, but prints:
```
(No output yet — complete the GetCustomerSummary method in Program.cs)
```
because the method body is left as a `TODO` for the candidate.

## How to use in a mock interview
1. Read the candidate the problem statement from
   `docs/Citi_Karat_CSharp_Completion_Question.md` (don't show the file directly —
   that's the trainer copy with rubric + solution links).
2. Hand them only `Program.cs` (or share the "Starter Code" section of the md file).
3. Have them implement `GetCustomerSummary` while narrating their approach out loud,
   the way an actual Karat Interview Engineer expects.
4. Once they have a working version, run `dotnet run` to verify output matches:
   ```
   C1 -> Credit: 800, Debit: 150, Net: 650
   C2 -> Credit: 0, Debit: 200, Net: -200
   C3 -> Credit: 1000, Debit: 0, Net: 1000
   ```
5. Use the optional follow-up at the end of the question doc (filter to negative
   `NetBalance`) to test how they extend working code under time pressure.
6. Compare their solution against `docs/ReferenceSolution_TrainerOnly.txt` and score
   using the rubric table in the question doc.
