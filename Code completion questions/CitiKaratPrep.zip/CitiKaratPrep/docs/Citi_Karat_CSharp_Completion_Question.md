# Citi (Karat) – C# Console Code Completion Question
**Level:** Intermediate (.NET Associate) | **Format:** Karat-style code completion | **Time box:** 15–20 min

---

## How to run this in a mock session
Karat gives a **partially built program** and asks the candidate to complete the missing method(s) — not write everything from scratch. The candidate must **narrate their approach out loud** before/while typing, since the Interview Engineer scores reasoning + edge-case handling, not just final output. Give the student only the **"Starter Code"** section below. Hide the **"Reference Solution"** until after.

---

## Problem Statement (read this to the student)

> You work in Citi's transaction processing team. You're given a list of customer transactions for a day. Each transaction has a `CustomerId`, an `Amount` (can be negative for a refund/debit), and a `Type` ("Credit" or "Debit").
>
> Complete the method `GetCustomerSummary` so that it returns, for each customer, their **total credit amount**, **total debit amount**, and **net balance** (credit − debit) for the day — sorted by `CustomerId` ascending.
>
> If a customer has no transactions of a given type, treat that total as 0. If the input list is null or empty, return an empty result.

### Sample Input
```
[
  { CustomerId: "C1", Amount: 500, Type: "Credit" },
  { CustomerId: "C2", Amount: 200, Type: "Debit"  },
  { CustomerId: "C1", Amount: 150, Type: "Debit"  },
  { CustomerId: "C1", Amount: 300, Type: "Credit" },
  { CustomerId: "C3", Amount: 1000, Type: "Credit" }
]
```

### Expected Output
```
C1 -> Credit: 800, Debit: 150, Net: 650
C2 -> Credit: 0, Debit: 200, Net: -200
C3 -> Credit: 1000, Debit: 0, Net: 1000
```

### Constraints / Edge Cases to probe (ask the candidate to call these out)
- Empty or null transaction list → empty output, no exception
- `Type` casing might vary ("credit" vs "Credit") — should it be case-insensitive? (good clarifying question for the candidate to ask)
- Unknown/invalid `Type` values → how should they be handled? (discuss, don't necessarily code for it)
- Output must be sorted by `CustomerId`

---

## Starter Code (give this to the candidate)

```csharp
using System;
using System.Collections.Generic;
using System.Linq;

namespace CitiTransactionProcessor
{
    public class Transaction
    {
        public string CustomerId { get; set; }
        public decimal Amount { get; set; }
        public string Type { get; set; } // "Credit" or "Debit"
    }

    public class CustomerSummary
    {
        public string CustomerId { get; set; }
        public decimal TotalCredit { get; set; }
        public decimal TotalDebit { get; set; }
        public decimal NetBalance => TotalCredit - TotalDebit;
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Transaction> transactions = new List<Transaction>
            {
                new Transaction { CustomerId = "C1", Amount = 500,  Type = "Credit" },
                new Transaction { CustomerId = "C2", Amount = 200,  Type = "Debit"  },
                new Transaction { CustomerId = "C1", Amount = 150,  Type = "Debit"  },
                new Transaction { CustomerId = "C1", Amount = 300,  Type = "Credit" },
                new Transaction { CustomerId = "C3", Amount = 1000, Type = "Credit" }
            };

            List<CustomerSummary> result = GetCustomerSummary(transactions);

            foreach (var summary in result)
            {
                Console.WriteLine($"{summary.CustomerId} -> Credit: {summary.TotalCredit}, " +
                                   $"Debit: {summary.TotalDebit}, Net: {summary.NetBalance}");
            }
        }

        // TODO: Complete this method.
        // Return one CustomerSummary per distinct CustomerId, sorted by CustomerId ascending.
        static List<CustomerSummary> GetCustomerSummary(List<Transaction> transactions)
        {
            // your code here
            return null;
        }
    }
}
```

---

## Reference Solution (trainer only — don't show first)

```csharp
static List<CustomerSummary> GetCustomerSummary(List<Transaction> transactions)
{
    if (transactions == null || transactions.Count == 0)
        return new List<CustomerSummary>();

    var grouped = transactions
        .GroupBy(t => t.CustomerId)
        .Select(g => new CustomerSummary
        {
            CustomerId = g.Key,
            TotalCredit = g.Where(t => string.Equals(t.Type, "Credit", StringComparison.OrdinalIgnoreCase))
                            .Sum(t => t.Amount),
            TotalDebit = g.Where(t => string.Equals(t.Type, "Debit", StringComparison.OrdinalIgnoreCase))
                           .Sum(t => t.Amount)
        })
        .OrderBy(s => s.CustomerId)
        .ToList();

    return grouped;
}
```

**Non-LINQ alternative** (ask candidates to also try this if they only know LINQ — Karat sometimes pushes "now do it without LINQ" as a follow-up):

```csharp
static List<CustomerSummary> GetCustomerSummary(List<Transaction> transactions)
{
    var result = new List<CustomerSummary>();
    if (transactions == null || transactions.Count == 0) return result;

    var map = new Dictionary<string, CustomerSummary>();

    foreach (var t in transactions)
    {
        if (!map.ContainsKey(t.CustomerId))
            map[t.CustomerId] = new CustomerSummary { CustomerId = t.CustomerId };

        if (string.Equals(t.Type, "Credit", StringComparison.OrdinalIgnoreCase))
            map[t.CustomerId].TotalCredit += t.Amount;
        else if (string.Equals(t.Type, "Debit", StringComparison.OrdinalIgnoreCase))
            map[t.CustomerId].TotalDebit += t.Amount;
    }

    result = map.Values.OrderBy(s => s.CustomerId).ToList();
    return result;
}
```

---

## What to score the candidate on (Karat-style rubric)

| Dimension | Look for |
|---|---|
| **Clarifying questions** | Did they ask about null input, case sensitivity, sort order, unknown `Type` values *before* coding? |
| **Correctness** | Matches expected output exactly, handles empty/null list |
| **Use of collections** | Comfortable with `Dictionary`, `GroupBy`, `Sum`, `OrderBy` — core C# associate skills |
| **Communication** | Narrates approach while typing, doesn't go silent for 5+ minutes |
| **Iteration** | Starts with a working brute-force version, then refines — perfect code with zero iteration is actually flagged as suspicious in real Karat scoring |
| **Edge case handling** | Explicitly tests/mentions empty list, single customer, all-debit customer |
| **Code quality** | Meaningful names, no magic strings repeated everywhere, reasonable method length |

---

## Optional follow-up (if they finish early — Karat often adds a twist)
> "Now the bank wants only customers whose **net balance is negative** (potential overdraft risk) returned, still sorted by CustomerId." — tests whether they can quickly extend/filter their own working solution rather than rewrite it.
