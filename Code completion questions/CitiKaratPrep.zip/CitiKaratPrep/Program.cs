using System;
using System.Collections.Generic;
using System.Linq;

namespace CitiTransactionProcessor
{
    public class Transaction
    {
        public string CustomerId { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Type { get; set; } = string.Empty; // "Credit" or "Debit"
    }

    public class CustomerSummary
    {
        public string CustomerId { get; set; } = string.Empty;
        public decimal TotalCredit { get; set; }
        public decimal TotalDebit { get; set; }
        public decimal NetBalance => TotalCredit - TotalDebit;
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Transaction> transactions = new List<Transaction>
            {
                new Transaction { CustomerId = "C1", Amount = 500,  Type = "Credit" },
                new Transaction { CustomerId = "C2", Amount = 200,  Type = "Debit"  },
                new Transaction { CustomerId = "C1", Amount = 150,  Type = "Debit"  },
                new Transaction { CustomerId = "C1", Amount = 300,  Type = "Credit" },
                new Transaction { CustomerId = "C3", Amount = 1000, Type = "Credit" }
            };

            List<CustomerSummary> result = GetCustomerSummary(transactions);

            if (result.Count == 0)
            {
                Console.WriteLine("(No output yet — complete the GetCustomerSummary method in Program.cs)");
            }

            foreach (var summary in result)
            {
                Console.WriteLine($"{summary.CustomerId} -> Credit: {summary.TotalCredit}, " +
                                   $"Debit: {summary.TotalDebit}, Net: {summary.NetBalance}");
            }
        }

        // ---------------------------------------------------------------------
        // TODO (Candidate task):
        // Complete this method.
        // Return one CustomerSummary per distinct CustomerId, sorted by
        // CustomerId ascending. TotalCredit / TotalDebit should sum all
        // transactions of that type for the customer. If a customer has no
        // transactions of a given type, that total should be 0.
        // If the input list is null or empty, return an empty list.
        // ---------------------------------------------------------------------
        static List<CustomerSummary> GetCustomerSummary(List<Transaction> transactions)
        {
            // your code here
            return new List<CustomerSummary>();
        }
    }
}
