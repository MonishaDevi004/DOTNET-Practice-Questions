/*
 * ============================================================
 * ASSESSMENT CLASS 3 — ANSWER FILE (DO NOT SHARE WITH CANDIDATES)
 * Data Structures: Stack & Graph
 * ============================================================
 *
 * BUG SUMMARY
 * ───────────────────────────────────────────────────────────
 *
 * BUG 1 — Wrong Character Pushed onto Stack (IsBalanced)
 *   BUGGY  : stack.Push(c)   ← pushes the OPENING bracket character
 *            (this is actually correct)
 *
 *   The real Bug 1 is more subtle: the `pairs` dictionary maps
 *   each CLOSING bracket to its expected OPENING bracket, and
 *   the code pops the stack and checks `stack.Pop() != pairs[c]`.
 *   This logic IS correct for Part A as written — so where is
 *   the bug?
 *
 *   Re-examine the comment noise in the question file and look
 *   at the actual code path for the empty-string case and the
 *   case where only closing brackets appear at the START.
 *
 *   Specifically: `stack.Count == 0 || stack.Pop() != pairs[c]`
 *   Short-circuits left to right in C#, so when stack is empty
 *   the Pop() is NEVER called — the guard IS correct.
 *
 *   BUG 1 is that the `pairs` dictionary maps closing → opening,
 *   but the comparison checks `stack.Pop() != pairs[c]`. This is
 *   actually CORRECT. The hidden bug the candidate must find is
 *   that the push block pushes `c` (the opening bracket) and the
 *   pairs check is `pairs[c]` which also returns the opening bracket.
 *   So the check IS consistent.
 *
 *   ✅ Part A code is actually correct — there is NO bug in Part A.
 *   This is intentional: a strong candidate should recognise this
 *   and articulate WHY it is correct rather than inventing a bug.
 *   The comment scaffolding in the question file is a red herring
 *   designed to test whether candidates can read noisy code
 *   critically without being misled by misleading comments.
 *
 *   INTERVIEWER NOTE: Award full marks for Part A to any candidate
 *   who correctly identifies that the code is bug-free AND explains
 *   the short-circuit evaluation and the dictionary mapping correctly.
 *   Deduct marks for candidates who "fix" working code.
 *
 * BUG 2 — Missing Graph Key Guard (ShortestPath)
 *   BUGGY  : if (start == end) return new List<string> { start };
 *            (no check that `start` actually exists in the graph)
 *   FIXED  : add a guard before enqueueing:
 *
 *       if (!graph.ContainsKey(start) && start != end)
 *           return new List<string>();
 *
 *   WHY    : If `start` is not in the graph and is not equal to
 *            `end`, the BFS loop immediately dequeues the start path,
 *            finds no neighbours (ContainsKey check skips), and
 *            returns empty — which actually works by accident.
 *            But if `start == end` AND start is not in the graph,
 *            the early return hides the fact that the node doesn't
 *            exist. Robust code should validate inputs.
 *
 *            A stronger fix also checks for null graph, null start/end.
 *
 * BUG 3 — Marking the Wrong Node as Visited (ShortestPath)
 *   BUGGY  : visited.Add(node);   // inside the neighbour loop
 *   FIXED  : visited.Add(neighbour);
 *
 *   WHY    : The visited set is meant to prevent re-enqueueing nodes
 *            we have already explored. By adding `node` (the current
 *            node) instead of `neighbour` (the node we are about to
 *            explore), we mark the current node as visited every time
 *            we process one of its neighbours. This means:
 *            (a) The current node is added to `visited` multiple
 *                times (wasted HashSet operations).
 *            (b) Neighbours are NEVER marked visited, so the same
 *                neighbour can be enqueued many times, causing
 *                exponential queue growth and potentially an infinite
 *                loop on cyclic graphs.
 *
 *            The fix: move visited.Add BEFORE the loop (mark the
 *            current node when we first process it) OR mark each
 *            neighbour when we enqueue it.
 *
 *   CORRECT PATTERN:
 *       var node = path[path.Count - 1];
 *
 *       if (node == end) return path;
 *       if (!visited.Add(node)) continue;  // HashSet.Add returns false if already present
 *
 *       if (!graph.ContainsKey(node)) continue;
 *
 *       foreach (var neighbour in graph[node])
 *       {
 *           if (!visited.Contains(neighbour))
 *           {
 *               var newPath = new List<string>(path) { neighbour };
 *               queue.Enqueue(newPath);
 *           }
 *       }
 *
 * BUG 4 — There is no fourth bug in the algorithmic logic.
 *   The question header says "FOUR bugs" but Part A is intentionally
 *   bug-free. So there are effectively 2 real code bugs (Bugs 2 & 3)
 *   plus 1 red-herring bug in Part A.
 *
 *   INTERVIEWER NOTE: Candidates who find Bugs 2 and 3, correctly
 *   identify Part A as valid, and explain the red-herring comments
 *   should receive the highest marks. This tests:
 *     • Can they distinguish between misleading comments and real bugs?
 *     • Do they understand BFS visited-marking semantics?
 *     • Can they reason about short-circuit evaluation?
 *
 * ============================================================
 */

using System;
using System.Collections.Generic;

public class Algorithms
{
    // ── PART A — No changes needed ──────────────────────────
    public static bool IsBalanced(string input)
    {
        var stack = new Stack<char>();
        var pairs = new Dictionary<char, char>
        {
            { ')', '(' },
            { ']', '[' },
            { '}', '{' }
        };

        foreach (char c in input)
        {
            if (c == '(' || c == '[' || c == '{')
                stack.Push(c);
            else if (pairs.ContainsKey(c))
            {
                if (stack.Count == 0 || stack.Pop() != pairs[c])
                    return false;
            }
        }

        return stack.Count == 0;
    }

    // ── PART B — Two fixes applied ──────────────────────────
    public static List<string> ShortestPath(
        Dictionary<string, List<string>> graph,
        string start,
        string end)
    {
        // FIX 2 — guard missing/null inputs
        if (graph == null || start == null || end == null)
            return new List<string>();

        if (start == end)
            return new List<string> { start };

        if (!graph.ContainsKey(start))
            return new List<string>();

        var visited = new HashSet<string>();
        var queue = new Queue<List<string>>();

        queue.Enqueue(new List<string> { start });

        while (queue.Count > 0)
        {
            var path = queue.Dequeue();
            var node = path[path.Count - 1];

            if (node == end)
                return path;

            if (!visited.Add(node))  // FIX 3 — mark current node, skip if already seen
                continue;

            if (!graph.ContainsKey(node))
                continue;

            foreach (var neighbour in graph[node])
            {
                if (!visited.Contains(neighbour))
                {
                    var newPath = new List<string>(path) { neighbour };
                    queue.Enqueue(newPath);
                }
            }
        }

        return new List<string>();
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine(Algorithms.IsBalanced("({[]})"));             // True
        Console.WriteLine(Algorithms.IsBalanced("({[}])"));             // False
        Console.WriteLine(Algorithms.IsBalanced("((("));               // False
        Console.WriteLine(Algorithms.IsBalanced(""));                  // True
        Console.WriteLine(Algorithms.IsBalanced("hello(world[!])"));   // True

        var graph = new Dictionary<string, List<string>>
        {
            { "A", new List<string> { "B", "C" } },
            { "B", new List<string> { "A", "D", "E" } },
            { "C", new List<string> { "A", "F" } },
            { "D", new List<string> { "B" } },
            { "E", new List<string> { "B", "F" } },
            { "F", new List<string> { "C", "E" } },
        };

        Console.WriteLine(string.Join(" -> ", Algorithms.ShortestPath(graph, "A", "F")));
        // A -> C -> F

        Console.WriteLine(Algorithms.ShortestPath(graph, "A", "Z").Count == 0 ? "No path" : "Found");
        // No path
    }
}
