/*
 * ============================================================
 * ASSESSMENT CLASS 1 — ANSWER FILE (DO NOT SHARE WITH CANDIDATES)
 * Generic Cache with Expiry
 * ============================================================
 *
 * BUG SUMMARY
 * ───────────────────────────────────────────────────────────
 *
 * BUG 1 — Wrong Generic Constraint (Line: class declaration)
 *   BUGGY  : where TKey : class
 *   FIXED  : where TKey : notnull
 *
 *   WHY    : Constraining TKey to `class` prevents value types
 *            (int, Guid, enum, struct) from being used as keys,
 *            which is unnecessarily restrictive for a cache.
 *            `notnull` allows both reference and value types
 *            while still preventing null keys — which is the
 *            correct requirement for a Dictionary key.
 *
 * BUG 2 — Inverted Expiry Comparison (Get method)
 *   BUGGY  : if (DateTime.UtcNow < entry.ExpiresAt)
 *   FIXED  : if (DateTime.UtcNow >= entry.ExpiresAt)
 *
 *   WAIT — actually re-read the logic carefully:
 *   The original `<` check returns the value when "now is BEFORE
 *   expiry", which is actually CORRECT for "not yet expired".
 *
 *   The real bug is the MISSING `_store.Remove(key)` call for
 *   expired hits — a common pattern called lazy eviction.
 *   Without it, stale entries linger indefinitely until CleanUp()
 *   is called manually, causing memory leaks in long-running apps.
 *
 *   FIXED  :
 *       if (_store.TryGetValue(key, out var entry))
 *       {
 *           if (DateTime.UtcNow < entry.ExpiresAt)
 *               return entry.Value;
 *
 *           _store.Remove(key);   // lazy eviction  ← ADD THIS
 *       }
 *       return default;
 *
 * BUG 3 — Mutating Dictionary While Iterating (CleanUp method)
 *   BUGGY  : foreach (var key in _store.Keys) { _store.Remove(key); }
 *   FIXED  : Collect keys first, then remove.
 *
 *   WHY    : Modifying a Dictionary's collection while enumerating
 *            its Keys throws InvalidOperationException at runtime
 *            ("Collection was modified; enumeration operation
 *            may not execute."). Must snapshot the keys first.
 *
 *   FIXED  :
 *       var expiredKeys = _store
 *           .Where(kvp => kvp.Value.ExpiresAt <= DateTime.UtcNow)
 *           .Select(kvp => kvp.Key)
 *           .ToList();
 *
 *       foreach (var key in expiredKeys)
 *           _store.Remove(key);
 *
 * BUG 4 — LINQ Performance Issue (LiveCount property)
 *   BUGGY  : _store.Count(kvp => kvp.Value.ExpiresAt > DateTime.UtcNow)
 *   FIXED  : see below
 *
 *   WHY    : DateTime.UtcNow is a property call with a kernel
 *            syscall underneath. Inside a LINQ Count() predicate,
 *            it is evaluated ONCE PER ELEMENT in the dictionary.
 *            For a large cache this introduces unnecessary overhead
 *            AND inconsistency (the "now" snapshot drifts across
 *            iterations). Capture it once before the query.
 *
 *   FIXED  :
 *       var now = DateTime.UtcNow;
 *       return _store.Count(kvp => kvp.Value.ExpiresAt > now);
 *
 * ============================================================
 */

using System;
using System.Collections.Generic;
using System.Linq;

public class TimedCache<TKey, TValue> where TKey : notnull   // FIX 1
{
    private class CacheEntry
    {
        public TValue Value { get; set; }
        public DateTime ExpiresAt { get; set; }
    }

    private readonly Dictionary<TKey, CacheEntry> _store = new();

    public void Set(TKey key, TValue value, int ttlSeconds)
    {
        _store[key] = new CacheEntry
        {
            Value = value,
            ExpiresAt = DateTime.UtcNow.AddSeconds(ttlSeconds)
        };
    }

    public TValue Get(TKey key)
    {
        if (_store.TryGetValue(key, out var entry))
        {
            if (DateTime.UtcNow < entry.ExpiresAt)
                return entry.Value;

            _store.Remove(key);  // FIX 2 — lazy eviction
        }
        return default;
    }

    public void CleanUp()
    {
        // FIX 3 — snapshot keys before mutating the dictionary
        var expiredKeys = _store
            .Where(kvp => kvp.Value.ExpiresAt <= DateTime.UtcNow)
            .Select(kvp => kvp.Key)
            .ToList();

        foreach (var key in expiredKeys)
            _store.Remove(key);
    }

    public int LiveCount
    {
        get
        {
            var now = DateTime.UtcNow;  // FIX 4 — capture once
            return _store.Count(kvp => kvp.Value.ExpiresAt > now);
        }
    }
}

class Program
{
    static void Main()
    {
        var cache = new TimedCache<string, int>();

        cache.Set("a", 10, 2);
        cache.Set("b", 20, 60);

        Console.WriteLine(cache.Get("a"));       // 10
        Console.WriteLine(cache.Get("b"));       // 20
        Console.WriteLine(cache.LiveCount);      // 2

        System.Threading.Thread.Sleep(2500);

        Console.WriteLine(cache.Get("a"));       // 0
        Console.WriteLine(cache.LiveCount);      // 1

        cache.CleanUp();
        Console.WriteLine(cache.LiveCount);      // 1
    }
}
