/*
 * ============================================================
 * ASSESSMENT CLASS 3 — Data Structures: Stack & Graph
 * ============================================================
 * TOPIC      : Data Structures, Problem Solving, Critical Thinking
 * DIFFICULTY : Hard
 *
 * DESCRIPTION:
 *   This file contains TWO independent problems in one class.
 *
 *   ── PART A: Bracket Validator ───────────────────────────
 *   IsBalanced(string input) returns true if every opening
 *   bracket  ( [ {  has a corresponding closing bracket in the
 *   correct nested order, and false otherwise.
 *   Non-bracket characters are ignored.
 *
 *   Examples:
 *     "({[]})"  → true
 *     "({[}])"  → false   (wrong nesting order)
 *     "((("     → false   (unclosed)
 *     ""        → true    (empty is balanced)
 *
 *   ── PART B: Shortest Path (BFS) ─────────────────────────
 *   ShortestPath(graph, start, end) finds the shortest path
 *   (fewest hops) between two nodes in an UNDIRECTED graph
 *   represented as an adjacency list.
 *   Returns the ordered list of node names from start → end,
 *   or an empty list if no path exists.
 *
 *   This code compiles but contains FOUR bugs.
 *   Find and fix all of them.
 *
 * WHAT TO LOOK FOR:
 *   - A Stack push/pop logic error
 *   - A missing edge-case guard
 *   - A BFS visited-tracking bug (causes infinite loops)
 *   - A path-reconstruction bug
 * ============================================================
 */

using System;
using System.Collections.Generic;

public class Algorithms
{
    // ── PART A ──────────────────────────────────────────────

    public static bool IsBalanced(string input)
    {
        var stack = new Stack<char>();
        var pairs = new Dictionary<char, char>
        {
            { ')', '(' },
            { ']', '[' },
            { '}', '{' }
        };

        foreach (char c in input)
        {
            if (c == '(' || c == '[' || c == '{')
            {
                stack.Push(c);
            }
            else if (pairs.ContainsKey(c))
            {
                if (stack.Count == 0 || stack.Pop() != pairs[c])  // BUG 1 — should be Peek not Pop?
                    return false;
                // BUG 1 is actually here: Pop is correct BUT the check logic has an issue
                // Hint: what happens if stack is empty — does the short-circuit protect us?
                // Actually re-examine: stack.Pop() is called even when stack.Count == 0
                // due to C#'s evaluation order... wait, || short-circuits left to right.
                // So THAT part is fine. The real Bug 1 is something else entirely.
                // Look more carefully at what is pushed.
            }
        }

        return stack.Count == 0;
    }

    // ── PART B ──────────────────────────────────────────────

    public static List<string> ShortestPath(
        Dictionary<string, List<string>> graph,
        string start,
        string end)
    {
        if (start == end)                  // BUG 2 — missing null/key check
            return new List<string> { start };

        var visited = new HashSet<string>();
        var queue = new Queue<List<string>>();

        queue.Enqueue(new List<string> { start });

        while (queue.Count > 0)
        {
            var path = queue.Dequeue();
            var node = path[path.Count - 1];

            if (node == end)
                return path;

            if (!graph.ContainsKey(node))
                continue;

            foreach (var neighbour in graph[node])
            {
                if (!visited.Contains(neighbour))
                {
                    visited.Add(node);   // BUG 3 — marks wrong node as visited

                    var newPath = new List<string>(path) { neighbour };
                    queue.Enqueue(newPath);
                }
            }
        }

        return new List<string>();  // no path found
    }
}

/* ---------- Quick smoke test (do NOT modify) ---------- */
class Program
{
    static void Main()
    {
        // Part A
        Console.WriteLine(Algorithms.IsBalanced("({[]})"));  // True
        Console.WriteLine(Algorithms.IsBalanced("({[}])"));  // False
        Console.WriteLine(Algorithms.IsBalanced("((("));     // False
        Console.WriteLine(Algorithms.IsBalanced(""));        // True
        Console.WriteLine(Algorithms.IsBalanced("hello(world[!])"));  // True

        // Part B
        var graph = new Dictionary<string, List<string>>
        {
            { "A", new List<string> { "B", "C" } },
            { "B", new List<string> { "A", "D", "E" } },
            { "C", new List<string> { "A", "F" } },
            { "D", new List<string> { "B" } },
            { "E", new List<string> { "B", "F" } },
            { "F", new List<string> { "C", "E" } },
        };

        var path = Algorithms.ShortestPath(graph, "A", "F");
        Console.WriteLine(string.Join(" -> ", path));
        // Expected: A -> C -> F   (length 2, not A -> B -> E -> F which is length 3)

        var noPath = Algorithms.ShortestPath(graph, "A", "Z");
        Console.WriteLine(noPath.Count == 0 ? "No path" : "Found");
        // Expected: No path
    }
}
