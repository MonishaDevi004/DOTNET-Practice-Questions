/*
 * ============================================================
 * ASSESSMENT CLASS 2 — ANSWER FILE (DO NOT SHARE WITH CANDIDATES)
 * Order Aggregation with LINQ
 * ============================================================
 *
 * BUG SUMMARY
 * ───────────────────────────────────────────────────────────
 *
 * BUG 1 — Wrong GroupBy Key (TopSpenders)
 *   BUGGY  : .GroupBy(o => o.OrderId)
 *   FIXED  : .GroupBy(o => o.CustomerId)
 *
 *   WHY    : Grouping by OrderId creates one group per order,
 *            so the "customer" label becomes an order ID string
 *            and spend is per-order rather than per-customer.
 *            The requirement is to aggregate across all orders
 *            belonging to the same customer.
 *
 * BUG 2 — Wrong Sort Direction (TopSpenders)
 *   BUGGY  : .OrderBy(x => x.TotalSpend)
 *   FIXED  : .OrderByDescending(x => x.TotalSpend)
 *
 *   WHY    : OrderBy sorts ascending (lowest first), so Take(n)
 *            returns the LOWEST spenders. The requirement is
 *            "top N … highest first", so OrderByDescending is needed.
 *
 * BUG 3 — Repeated Deferred Enumeration (LowStockProducts)
 *   BUGGY  : var allItems = _orders.SelectMany(o => o.Items);
 *            (then used inside a chain that is itself executed later)
 *   FIXED  : var allItems = _orders.SelectMany(o => o.Items).ToList();
 *
 *   WHY    : SelectMany returns an IEnumerable<LineItem> with deferred
 *            execution. Because allItems is used as the source of
 *            another LINQ chain (GroupBy → Select → Where → OrderBy
 *            → Select), every time the outer query is iterated the
 *            full SelectMany traversal runs again from scratch.
 *            In this method it runs once, but if the caller iterates
 *            the returned IEnumerable multiple times (e.g. foreach +
 *            .Count()) the inner loop executes N×M times.
 *
 *            Calling .ToList() materialises the sequence immediately,
 *            making the allocation cost O(1) no matter how many times
 *            the outer result is consumed. This is a classic
 *            "deferred LINQ source" performance trap.
 *
 * BUG 4 — Wrong Threshold Comparison (LowStockProducts)
 *   BUGGY  : .Where(x => x.TotalSold <= threshold)
 *   FIXED  : .Where(x => x.TotalSold < threshold)
 *
 *   WHY    : The spec says "strictly LESS THAN the threshold".
 *            Using <= includes products AT the threshold (e.g. Widget
 *            with exactly 6 units when threshold is 6), violating
 *            the requirement. The smoke test confirms: Widget has
 *            5 + 1 = 6 units sold and threshold = 6, so Widget must
 *            NOT appear in the output.
 *
 * ============================================================
 */

using System;
using System.Collections.Generic;
using System.Linq;

public record LineItem(string Product, int Qty, decimal UnitPrice);
public record Order(int OrderId, string CustomerId, List<LineItem> Items);

public class ReportService
{
    private readonly List<Order> _orders;

    public ReportService(List<Order> orders) => _orders = orders;

    public IEnumerable<(string Customer, decimal TotalSpend)> TopSpenders(int n)
    {
        return _orders
            .GroupBy(o => o.CustomerId)   // FIX 1
            .Select(g => (
                Customer: g.Key,
                TotalSpend: g.SelectMany(o => o.Items)
                             .Sum(li => li.Qty * li.UnitPrice)
            ))
            .Where(x => x.TotalSpend > 0)
            .OrderByDescending(x => x.TotalSpend)   // FIX 2
            .Take(n);
    }

    public IEnumerable<string> LowStockProducts(int threshold)
    {
        var allItems = _orders.SelectMany(o => o.Items).ToList();   // FIX 3

        return allItems
            .GroupBy(li => li.Product)
            .Select(g => (Product: g.Key, TotalSold: g.Sum(li => li.Qty)))
            .Where(x => x.TotalSold < threshold)   // FIX 4
            .OrderBy(x => x.Product)
            .Select(x => x.Product);
    }
}

class Program
{
    static void Main()
    {
        var orders = new List<Order>
        {
            new(1, "alice", new List<LineItem>
            {
                new("Widget", 5, 10m),
                new("Gadget", 2, 25m),
            }),
            new(2, "bob", new List<LineItem>
            {
                new("Widget", 1, 10m),
                new("Doohickey", 3, 5m),
            }),
            new(3, "alice", new List<LineItem>
            {
                new("Thingamajig", 10, 8m),
            }),
        };

        var svc = new ReportService(orders);

        Console.WriteLine("=== Top 2 Spenders ===");
        foreach (var (customer, spend) in svc.TopSpenders(2))
            Console.WriteLine($"{customer}: {spend:C}");
        // alice: $180.00
        // bob:   $25.00

        Console.WriteLine("\n=== Low Stock (threshold = 6) ===");
        foreach (var p in svc.LowStockProducts(6))
            Console.WriteLine(p);
        // Doohickey
        // Gadget
    }
}
