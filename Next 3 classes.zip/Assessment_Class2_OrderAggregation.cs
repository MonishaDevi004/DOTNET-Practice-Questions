/*
 * ============================================================
 * ASSESSMENT CLASS 2 — Order Aggregation with LINQ
 * ============================================================
 * TOPIC      : LINQ, Problem Solving, Performance
 * DIFFICULTY : Medium–Hard
 *
 * DESCRIPTION:
 *   You are given a set of sales orders. Each order belongs to
 *   a customer and contains multiple line items (product + qty + unit price).
 *
 *   The ReportService class must produce two outputs:
 *
 *     1. TopSpenders(n)
 *        Returns the top N customers ranked by their TOTAL spend
 *        (sum of qty × unit price across all their orders),
 *        highest first. Customers with zero spend are excluded.
 *
 *     2. LowStockProducts(threshold)
 *        Returns product names whose TOTAL units sold across ALL
 *        orders is strictly LESS THAN the threshold — sorted
 *        alphabetically.
 *
 *   This code compiles but contains FOUR bugs.
 *   Find and fix all of them.
 *
 * WHAT TO LOOK FOR:
 *   - Wrong LINQ aggregation (GroupBy key or selector)
 *   - Incorrect ordering direction
 *   - An n+1 / repeated enumeration performance problem
 *   - An off-by-one in the threshold filter
 * ============================================================
 */

using System;
using System.Collections.Generic;
using System.Linq;

public record LineItem(string Product, int Qty, decimal UnitPrice);

public record Order(int OrderId, string CustomerId, List<LineItem> Items);

public class ReportService
{
    private readonly List<Order> _orders;

    public ReportService(List<Order> orders) => _orders = orders;

    // Returns top N customers by total spend, highest first
    public IEnumerable<(string Customer, decimal TotalSpend)> TopSpenders(int n)
    {
        return _orders
            .GroupBy(o => o.OrderId)   // BUG 1
            .Select(g => (
                Customer: g.Key.ToString(),
                TotalSpend: g.SelectMany(o => o.Items)
                             .Sum(li => li.Qty * li.UnitPrice)
            ))
            .Where(x => x.TotalSpend > 0)
            .OrderBy(x => x.TotalSpend)   // BUG 2
            .Take(n);
    }

    // Returns product names whose total units sold < threshold, sorted A-Z
    public IEnumerable<string> LowStockProducts(int threshold)
    {
        var allItems = _orders.SelectMany(o => o.Items);   // BUG 3 (deferred)

        return allItems
            .GroupBy(li => li.Product)
            .Select(g => (Product: g.Key, TotalSold: g.Sum(li => li.Qty)))
            .Where(x => x.TotalSold <= threshold)   // BUG 4
            .OrderBy(x => x.Product)
            .Select(x => x.Product);
    }
}

/* ---------- Quick smoke test (do NOT modify) ---------- */
class Program
{
    static void Main()
    {
        var orders = new List<Order>
        {
            new(1, "alice", new List<LineItem>
            {
                new("Widget", 5, 10m),   // 50
                new("Gadget", 2, 25m),   // 50  → alice total: 100
            }),
            new(2, "bob", new List<LineItem>
            {
                new("Widget", 1, 10m),   // 10
                new("Doohickey", 3, 5m), // 15  → bob total: 25
            }),
            new(3, "alice", new List<LineItem>
            {
                new("Thingamajig", 10, 8m), // 80 → alice cumulative: 180
            }),
        };

        var svc = new ReportService(orders);

        Console.WriteLine("=== Top 2 Spenders ===");
        foreach (var (customer, spend) in svc.TopSpenders(2))
            Console.WriteLine($"{customer}: {spend:C}");
        // Expected:
        //   alice: $180.00
        //   bob:   $25.00

        Console.WriteLine("\n=== Low Stock (threshold = 6) ===");
        foreach (var p in svc.LowStockProducts(6))
            Console.WriteLine(p);
        // Expected: Doohickey, Gadget   (Widget=6 is NOT < 6; Thingamajig=10)
    }
}
