/*
 * ============================================================
 * ASSESSMENT CLASS 1 — Generic Cache with Expiry
 * ============================================================
 * TOPIC      : Generics, Collections, Performance
 * DIFFICULTY : Medium–Hard
 *
 * DESCRIPTION:
 *   You are given a generic in-memory cache class that stores
 *   key-value pairs with an expiry time (TTL in seconds).
 *
 *   The class should:
 *     1. Store any value type against a string key.
 *     2. Automatically treat entries as expired after their TTL.
 *     3. Remove ALL expired entries when CleanUp() is called.
 *     4. Return a default value (not throw) when a key is missing
 *        or expired.
 *     5. Report the count of currently LIVE (non-expired) entries.
 *
 *   This code compiles but contains FOUR bugs.
 *   Find and fix all of them.
 *
 * WHAT TO LOOK FOR:
 *   - Incorrect generic constraint usage
 *   - Off-by-one / wrong comparison in expiry logic
 *   - A collection-mutation bug during iteration
 *   - A subtle LINQ performance issue
 * ============================================================
 */

using System;
using System.Collections.Generic;
using System.Linq;

public class TimedCache<TKey, TValue> where TKey : class  // BUG 1
{
    private class CacheEntry
    {
        public TValue Value { get; set; }
        public DateTime ExpiresAt { get; set; }
    }

    private readonly Dictionary<TKey, CacheEntry> _store = new();

    public void Set(TKey key, TValue value, int ttlSeconds)
    {
        _store[key] = new CacheEntry
        {
            Value = value,
            ExpiresAt = DateTime.UtcNow.AddSeconds(ttlSeconds)
        };
    }

    public TValue Get(TKey key)
    {
        if (_store.TryGetValue(key, out var entry))
        {
            if (DateTime.UtcNow < entry.ExpiresAt)  // BUG 2
            {
                return entry.Value;
            }
        }
        return default;
    }

    public void CleanUp()
    {
        foreach (var key in _store.Keys)  // BUG 3
        {
            if (_store[key].ExpiresAt <= DateTime.UtcNow)
            {
                _store.Remove(key);
            }
        }
    }

    public int LiveCount =>
        _store.Count(kvp => kvp.Value.ExpiresAt > DateTime.UtcNow);  // BUG 4
}


/* ---------- Quick smoke test (do NOT modify) ---------- */
class Program
{
    static void Main()
    {
        var cache = new TimedCache<string, int>();

        cache.Set("a", 10, 2);   // expires in 2 seconds
        cache.Set("b", 20, 60);  // expires in 60 seconds

        Console.WriteLine(cache.Get("a"));          // Expected: 10
        Console.WriteLine(cache.Get("b"));          // Expected: 20
        Console.WriteLine(cache.LiveCount);         // Expected: 2

        System.Threading.Thread.Sleep(2500);        // wait 2.5 s

        Console.WriteLine(cache.Get("a"));          // Expected: 0 (expired → default)
        Console.WriteLine(cache.LiveCount);         // Expected: 1

        cache.CleanUp();
        Console.WriteLine(cache.LiveCount);         // Expected: 1 (only "b" remains)
    }
}
