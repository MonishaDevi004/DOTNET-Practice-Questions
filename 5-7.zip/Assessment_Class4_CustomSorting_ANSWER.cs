/*
 * ============================================================
 * ASSESSMENT CLASS 4 — ANSWER FILE (DO NOT SHARE WITH CANDIDATES)
 * Custom Sorting & IComparer<T>
 * ============================================================
 *
 * BUG SUMMARY
 * ───────────────────────────────────────────────────────────
 *
 * BUG 1 — IComparer Contract Violation: Duplicate Products Silently Dropped
 *   LOCATION : ProductComparer.Compare — the tertiary (name) tiebreaker
 *   BUGGY    : return string.Compare(x.Name, y.Name, ...)
 *              which can return 0 when two products have the same
 *              name, category, AND price.
 *   FIXED    : No change needed to this line, BUT the comparer must
 *              never return 0 for two *distinct* products inside a
 *              SortedSet — because SortedSet uses the comparer as its
 *              equality definition. When Compare returns 0, the set
 *              considers the two items identical and silently drops
 *              the second one.
 *
 *   The real symptom: if we add two DIFFERENT products that happen
 *   to share the same name, category, and price, only one is stored.
 *   The duplicate "Blender" in the smoke test is intentional and
 *   should be dropped — that part is CORRECT. But the bug candidates
 *   must identify is more subtle:
 *
 *   "Drill" and "Saw" both have Category="Tools" and Price=59.99.
 *   The name tiebreaker correctly returns non-zero for them, so they
 *   ARE both stored. The comparer contract is actually intact here.
 *
 *   THE REAL BUG 1 is in the null handling:
 *   BUGGY  : throw new ArgumentNullException();  (no parameter name)
 *   FIXED  : if (x == null && y == null) return 0;
 *            if (x == null) return -1;
 *            if (y == null) return 1;
 *
 *   WHY    : Throwing on null violates the IComparer<T> contract.
 *            SortedSet internals may call Compare with nulls during
 *            structural rebalancing in some edge cases. The contract
 *            requires null to be handled gracefully: null is considered
 *            less than any non-null value (matching Comparer<T>.Default
 *            behaviour). Throwing breaks the IComparer contract.
 *
 *   ADDITIONAL NOTE for interviewers:
 *   A strong candidate will also note that `Product` is a record type,
 *   and records implement value equality — but SortedSet uses the
 *   IComparer, NOT Equals/GetHashCode, for membership. So two records
 *   with identical property values ARE treated as duplicates by the
 *   SortedSet (Compare returns 0), which is the intended behaviour
 *   for the duplicate Blender test case. Candidates who understand
 *   this distinction score highly.
 *
 * BUG 2 — Case-Insensitive Category Search (BestInCategory)
 *   BUGGY  : .Where(p => p.Category == category)
 *   FIXED  : .Where(p => p.Category.Equals(category,
 *                StringComparison.OrdinalIgnoreCase))
 *
 *   WHY    : The smoke test calls BestInCategory("kitchen") with a
 *            lowercase "k". The stored category is "Kitchen" with an
 *            uppercase "K". The == operator uses ordinal case-sensitive
 *            comparison for strings, so the Where clause finds nothing
 *            and returns null instead of Microwave.
 *
 *            The ProductComparer uses OrdinalIgnoreCase for category
 *            comparison, so the sort is case-insensitive, but the
 *            search must match that behaviour explicitly.
 *
 * BUG 3 — Exclusive Upper Bound in PriceRange (off-by-one)
 *   BUGGY  : p.Price >= min && p.Price < max
 *   FIXED  : p.Price >= min && p.Price <= max
 *
 *   WHY    : The specification says INCLUSIVE on both ends. Using
 *            strict less-than (`< max`) excludes products priced
 *            exactly at the upper bound. The smoke test expects
 *            Drill and Saw ($59.99) to appear when max is $60.00,
 *            which works, BUT if the test used max=59.99, those
 *            products would be wrongly excluded. Change to `<=`.
 *
 * BUG 4 — Missing null guard / ArgumentNullException on Add
 *   BUGGY  : public void Add(Product p) => _set.Add(p);
 *   FIXED  : public void Add(Product p)
 *            {
 *                if (p == null) throw new ArgumentNullException(nameof(p));
 *                _set.Add(p);
 *            }
 *
 *   WHY    : Passing a null Product to SortedSet.Add causes the
 *            comparer's null-handling path to be exercised immediately.
 *            Even after fixing Bug 1's null handling in Compare, it
 *            is better practice to reject nulls at the API boundary
 *            with a clear exception than to let them silently enter
 *            the set as a "less-than-everything" sentinel.
 *
 * ============================================================
 */

using System;
using System.Collections.Generic;
using System.Linq;

public record Product(string Name, string Category, decimal Price);

public class ProductComparer : IComparer<Product>
{
    public int Compare(Product x, Product y)
    {
        // FIX 1 — honour IComparer contract for nulls
        if (x == null && y == null) return 0;
        if (x == null) return -1;
        if (y == null) return 1;

        int cat = string.Compare(x.Category, y.Category, StringComparison.OrdinalIgnoreCase);
        if (cat != 0) return cat;

        int price = y.Price.CompareTo(x.Price);   // descending price
        if (price != 0) return price;

        return string.Compare(x.Name, y.Name, StringComparison.OrdinalIgnoreCase);
    }
}

public class SortedCatalogue
{
    private readonly SortedSet<Product> _set;

    public SortedCatalogue()
    {
        _set = new SortedSet<Product>(new ProductComparer());
    }

    public void Add(Product p)
    {
        // FIX 4 — guard at API boundary
        if (p == null) throw new ArgumentNullException(nameof(p));
        _set.Add(p);
    }

    public Product BestInCategory(string category)
    {
        // FIX 2 — case-insensitive match
        return _set
            .Where(p => p.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
            .FirstOrDefault();
        // FirstOrDefault is correct here: because the SortedSet is sorted
        // by price descending within each category, the first match IS
        // the highest-priced item.
    }

    public IEnumerable<Product> PriceRange(decimal min, decimal max)
    {
        // FIX 3 — inclusive upper bound
        return _set.Where(p => p.Price >= min && p.Price <= max);
    }

    public IEnumerable<Product> All => _set;
}

class Program
{
    static void Main()
    {
        var catalogue = new SortedCatalogue();

        catalogue.Add(new Product("Blender",   "Kitchen", 49.99m));
        catalogue.Add(new Product("Toaster",   "Kitchen", 24.99m));
        catalogue.Add(new Product("Microwave", "Kitchen", 89.99m));
        catalogue.Add(new Product("Drill",     "Tools",   59.99m));
        catalogue.Add(new Product("Saw",       "Tools",   59.99m));
        catalogue.Add(new Product("Hammer",    "Tools",   15.00m));
        catalogue.Add(new Product("Blender",   "Kitchen", 49.99m));  // duplicate → dropped

        Console.WriteLine("=== Full Catalogue ===");
        foreach (var p in catalogue.All)
            Console.WriteLine($"  [{p.Category}] {p.Name} @ {p.Price:C}");

        Console.WriteLine("\n=== Best in Kitchen ===");
        Console.WriteLine(catalogue.BestInCategory("kitchen")?.Name ?? "Not found");
        // Microwave

        Console.WriteLine("\n=== Price Range $25–$60 ===");
        foreach (var p in catalogue.PriceRange(25m, 60m))
            Console.WriteLine($"  {p.Name} @ {p.Price:C}");
        // Blender, Drill, Saw
    }
}
