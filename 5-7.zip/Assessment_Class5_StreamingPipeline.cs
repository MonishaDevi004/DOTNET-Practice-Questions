/*
 * ============================================================
 * ASSESSMENT CLASS 5 — Streaming Pipeline & Memory Efficiency
 * ============================================================
 * TOPIC      : IEnumerable, yield, LINQ Performance, C# Concepts
 * DIFFICULTY : Hard
 *
 * DESCRIPTION:
 *   You are building a data pipeline that processes a large
 *   sequence of log entries (imagine millions of lines) without
 *   loading everything into memory at once.
 *
 *   The LogPipeline class must:
 *
 *     1. ParseLines(IEnumerable<string> lines)
 *        Lazily parses each raw string "LEVEL|timestamp|message"
 *        into a LogEntry. Malformed lines (wrong format) are
 *        silently skipped. Parsing must be deferred — no line
 *        should be parsed until the caller begins iterating.
 *
 *     2. FilterByLevel(IEnumerable<LogEntry> entries, string level)
 *        Lazily filters entries to only those matching `level`
 *        (case-insensitive). Again — fully deferred.
 *
 *     3. BatchSummarise(IEnumerable<LogEntry> entries, int batchSize)
 *        Consumes entries in fixed-size batches and for each batch
 *        yields a summary string:
 *           "Batch {n}: {count} entries, first={timestamp}, last={timestamp}"
 *        Batches must contain exactly `batchSize` items except
 *        possibly the final batch. Must be memory-efficient — never
 *        hold more than one batch in memory at a time.
 *
 *     4. CountByLevel(IEnumerable<LogEntry> entries)
 *        Returns a Dictionary<string, int> with the total count of
 *        entries per log level. This IS a terminal operation and
 *        may consume the full sequence.
 *
 *   This code compiles but contains FOUR bugs.
 *   Find and fix all of them.
 *
 * WHAT TO LOOK FOR:
 *   - Eager evaluation breaking the lazy pipeline
 *   - A yield / iterator method anti-pattern
 *   - A wrong batch boundary condition
 *   - A dictionary key case inconsistency
 * ============================================================
 */

using System;
using System.Collections.Generic;
using System.Linq;

public record LogEntry(string Level, DateTime Timestamp, string Message);

public class LogPipeline
{
    // 1. Lazy parse
    public IEnumerable<LogEntry> ParseLines(IEnumerable<string> lines)
    {
        // BUG 1: the entire input is materialised before any parsing begins
        var list = lines.ToList();
        foreach (var line in list)
        {
            var parts = line.Split('|');
            if (parts.Length != 3) continue;
            if (!DateTime.TryParse(parts[1], out var ts)) continue;
            yield return new LogEntry(parts[0].Trim(), ts, parts[2].Trim());
        }
    }

    // 2. Lazy filter
    public IEnumerable<LogEntry> FilterByLevel(IEnumerable<LogEntry> entries, string level)
    {
        // BUG 2: validation + yield in same method — this is a C# iterator gotcha
        if (entries == null) throw new ArgumentNullException(nameof(entries));
        if (string.IsNullOrEmpty(level)) throw new ArgumentException("level required");

        foreach (var e in entries)
        {
            if (e.Level.Equals(level, StringComparison.OrdinalIgnoreCase))
                yield return e;
        }
    }

    // 3. Batch summariser
    public IEnumerable<string> BatchSummarise(IEnumerable<LogEntry> entries, int batchSize)
    {
        var batch = new List<LogEntry>(batchSize);
        int batchNum = 0;

        foreach (var entry in entries)
        {
            batch.Add(entry);

            if (batch.Count == batchSize)  // BUG 3
            {
                batchNum++;
                yield return FormatBatch(batchNum, batch);
                batch.Clear();
            }
        }

        // emit final partial batch
        if (batch.Count > 0)
        {
            batchNum++;
            yield return FormatBatch(batchNum, batch);
        }
    }

    private static string FormatBatch(int n, List<LogEntry> batch) =>
        $"Batch {n}: {batch.Count} entries, " +
        $"first={batch[0].Timestamp:HH:mm:ss}, " +
        $"last={batch[batch.Count - 1].Timestamp:HH:mm:ss}";

    // 4. Count by level
    public Dictionary<string, int> CountByLevel(IEnumerable<LogEntry> entries)
    {
        var counts = new Dictionary<string, int>();
        foreach (var e in entries)
        {
            var key = e.Level;   // BUG 4
            if (counts.ContainsKey(key))
                counts[key]++;
            else
                counts[key] = 1;
        }
        return counts;
    }
}


/* ---------- Quick smoke test (do NOT modify) ---------- */
class Program
{
    static void Main()
    {
        var rawLines = new List<string>
        {
            "ERROR|2024-03-01 10:00:01|Disk full",
            "INFO|2024-03-01 10:00:02|Service started",
            "error|2024-03-01 10:00:03|Connection lost",   // lowercase level
            "WARN|2024-03-01 10:00:04|High memory",
            "MALFORMED LINE",                               // should be skipped
            "INFO|not-a-date|Bad timestamp",                // should be skipped
            "INFO|2024-03-01 10:00:05|Request received",
            "ERROR|2024-03-01 10:00:06|Timeout",
        };

        var pipeline = new LogPipeline();

        var entries = pipeline.ParseLines(rawLines);
        var errors  = pipeline.FilterByLevel(entries, "error");

        Console.WriteLine("=== Error entries ===");
        foreach (var e in errors)
            Console.WriteLine($"  {e.Timestamp:HH:mm:ss} — {e.Message}");
        // Expected: 10:00:01 Disk full, 10:00:03 Connection lost, 10:00:06 Timeout

        Console.WriteLine("\n=== Batches (size=3) ===");
        var allEntries = pipeline.ParseLines(rawLines);
        foreach (var summary in pipeline.BatchSummarise(allEntries, 3))
            Console.WriteLine($"  {summary}");
        // Expected:
        //   Batch 1: 3 entries, first=10:00:01, last=10:00:03
        //   Batch 2: 3 entries, first=10:00:04, last=10:00:05   ← Warn, Info, Error
        //   Wait — only 6 valid entries so: Batch 1 = 3, Batch 2 = 3
        //   (MALFORMED and bad-timestamp lines are skipped)

        Console.WriteLine("\n=== Count by level ===");
        var allEntries2 = pipeline.ParseLines(rawLines);
        var counts = pipeline.CountByLevel(allEntries2);
        foreach (var kv in counts.OrderBy(k => k.Key))
            Console.WriteLine($"  {kv.Key}: {kv.Value}");
        // Expected (case-normalised):
        //   ERROR: 3
        //   INFO: 2
        //   WARN: 1
    }
}
