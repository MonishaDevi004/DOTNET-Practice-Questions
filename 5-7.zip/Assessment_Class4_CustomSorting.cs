/*
 * ============================================================
 * ASSESSMENT CLASS 4 — Custom Sorting & IComparer<T>
 * ============================================================
 * TOPIC      : Generics, Collections, Critical Thinking
 * DIFFICULTY : Medium–Hard
 *
 * DESCRIPTION:
 *   You are given a product catalogue that must be sorted using
 *   a custom comparer. The sort rules (applied in priority order):
 *
 *     1. PRIMARY   : Category ascending (A → Z)
 *     2. SECONDARY : Price descending   (highest price first)
 *     3. TERTIARY  : Name ascending     (A → Z, as tiebreaker)
 *
 *   The SortedCatalogue class wraps a SortedSet<Product> and must:
 *     • Maintain the sort order automatically on insertion.
 *     • Expose a method BestInCategory(string category) that
 *       returns the single highest-priced product in that category,
 *       or null if the category doesn't exist.
 *     • Expose PriceRange(decimal min, decimal max) that returns
 *       all products whose price is between min and max INCLUSIVE,
 *       preserving the catalogue sort order.
 *
 *   This code compiles but contains FOUR bugs.
 *   Find and fix all of them.
 *
 * WHAT TO LOOK FOR:
 *   - A broken IComparer contract (anti-symmetry / equality)
 *   - SortedSet silently dropping items
 *   - Wrong LINQ filter for BestInCategory
 *   - Off-by-one in PriceRange filter
 * ============================================================
 */

using System;
using System.Collections.Generic;
using System.Linq;

public record Product(string Name, string Category, decimal Price);

public class ProductComparer : IComparer<Product>
{
    public int Compare(Product x, Product y)
    {
        if (x == null || y == null)
            throw new ArgumentNullException();

        int cat = string.Compare(x.Category, y.Category, StringComparison.OrdinalIgnoreCase);
        if (cat != 0) return cat;

        int price = y.Price.CompareTo(x.Price);
        if (price != 0) return price;

        return string.Compare(x.Name, y.Name, StringComparison.OrdinalIgnoreCase); // BUG 1
    }
}

public class SortedCatalogue
{
    private readonly SortedSet<Product> _set;

    public SortedCatalogue()
    {
        _set = new SortedSet<Product>(new ProductComparer());
    }

    public void Add(Product p) => _set.Add(p);

    public Product BestInCategory(string category)
    {
        return _set
            .Where(p => p.Category == category)   // BUG 2
            .FirstOrDefault();
    }

    public IEnumerable<Product> PriceRange(decimal min, decimal max)
    {
        return _set.Where(p => p.Price >= min && p.Price < max);  // BUG 3
    }

    public IEnumerable<Product> All => _set;
}


/* ---------- Quick smoke test (do NOT modify) ---------- */
class Program
{
    static void Main()
    {
        var catalogue = new SortedCatalogue();

        catalogue.Add(new Product("Blender",    "Kitchen",     49.99m));
        catalogue.Add(new Product("Toaster",    "Kitchen",     24.99m));
        catalogue.Add(new Product("Microwave",  "Kitchen",     89.99m));
        catalogue.Add(new Product("Drill",      "Tools",       59.99m));
        catalogue.Add(new Product("Saw",        "Tools",       59.99m));  // same price as Drill
        catalogue.Add(new Product("Hammer",     "Tools",       15.00m));
        catalogue.Add(new Product("Blender",    "Kitchen",     49.99m));  // duplicate — should be stored once

        Console.WriteLine("=== Full Catalogue ===");
        foreach (var p in catalogue.All)
            Console.WriteLine($"  [{p.Category}] {p.Name} @ {p.Price:C}");
        /*
         Expected order:
           [Kitchen] Microwave  @ $89.99
           [Kitchen] Blender    @ $49.99
           [Kitchen] Toaster    @ $24.99
           [Tools]   Drill      @ $59.99
           [Tools]   Saw        @ $59.99
           [Tools]   Hammer     @ $15.00
        */

        Console.WriteLine("\n=== Best in Kitchen ===");
        var best = catalogue.BestInCategory("kitchen");  // lowercase — should still find
        Console.WriteLine(best?.Name ?? "Not found");    // Expected: Microwave

        Console.WriteLine("\n=== Price Range $25–$60 ===");
        foreach (var p in catalogue.PriceRange(25m, 60m))
            Console.WriteLine($"  {p.Name} @ {p.Price:C}");
        /*
         Expected (inclusive both ends):
           Blender  @ $49.99
           Drill    @ $59.99
           Saw      @ $59.99
        */
    }
}
