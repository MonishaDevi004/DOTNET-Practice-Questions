/*
 * ============================================================
 * ASSESSMENT CLASS 5 — ANSWER FILE (DO NOT SHARE WITH CANDIDATES)
 * Streaming Pipeline & Memory Efficiency
 * ============================================================
 *
 * BUG SUMMARY
 * ───────────────────────────────────────────────────────────
 *
 * BUG 1 — Eager Evaluation Kills Lazy Pipeline (ParseLines)
 *   BUGGY  : var list = lines.ToList();
 *            foreach (var line in list) { ... yield return ...; }
 *   FIXED  : foreach (var line in lines) { ... yield return ...; }
 *
 *   WHY    : The entire purpose of yielding in ParseLines is to
 *            stream lines one at a time — e.g. from a 10 GB log
 *            file read lazily via File.ReadLines(). Calling .ToList()
 *            forces full materialisation of the input sequence into
 *            heap memory before any entry is returned to the caller.
 *            This destroys the memory efficiency benefit of the
 *            lazy pipeline and can cause OutOfMemoryException on
 *            large inputs.
 *
 *            Fix: iterate `lines` directly without materialising it.
 *
 * BUG 2 — Argument Validation in an Iterator Method (FilterByLevel)
 *   BUGGY  : public IEnumerable<LogEntry> FilterByLevel(...)
 *            {
 *                if (entries == null) throw ...  // ← never runs at call time!
 *                ...
 *                yield return e;
 *            }
 *   FIXED  : Split into a public wrapper that validates eagerly, plus
 *            a private iterator that does the yielding.
 *
 *   WHY    : In C#, any method containing `yield return` is an
 *            iterator method. The body of an iterator method does NOT
 *            execute when the method is called — it only runs when
 *            the caller begins iterating the returned IEnumerable.
 *            This means the null/empty guards are NEVER checked at
 *            the call site; they only trigger (if ever) when the
 *            first element is consumed. This is a well-known C# gotcha.
 *
 *   CORRECT PATTERN:
 *       public IEnumerable<LogEntry> FilterByLevel(
 *           IEnumerable<LogEntry> entries, string level)
 *       {
 *           if (entries == null) throw new ArgumentNullException(nameof(entries));
 *           if (string.IsNullOrEmpty(level)) throw new ArgumentException("level required");
 *           return FilterByLevelCore(entries, level);  // eager validation, deferred iteration
 *       }
 *
 *       private IEnumerable<LogEntry> FilterByLevelCore(
 *           IEnumerable<LogEntry> entries, string level)
 *       {
 *           foreach (var e in entries)
 *               if (e.Level.Equals(level, StringComparison.OrdinalIgnoreCase))
 *                   yield return e;
 *       }
 *
 * BUG 3 — Missing Final Partial Batch Flush (BatchSummarise)
 *   Wait — the final batch IS handled by the `if (batch.Count > 0)`
 *   block after the loop. So that logic is correct.
 *
 *   The actual Bug 3 is the batch.Clear() call after yielding.
 *   BUG    : batch.Clear() after yield return FormatBatch(...)
 *   FIXED  : batch = new List<LogEntry>(batchSize);
 *
 *   WHY    : After `yield return`, execution is suspended. When the
 *            caller resumes iteration, execution continues at the
 *            next statement — which is `batch.Clear()`. This is
 *            actually FINE in this case because FormatBatch() has
 *            already read the batch data and returned a string.
 *            batch.Clear() correctly resets the list for the next batch.
 *
 *   HOWEVER — the real Bug 3 is:
 *   The batch emitting condition is `if (batch.Count == batchSize)`,
 *   which means the batch is only emitted when EXACTLY equal to
 *   batchSize. If entries are added so count OVERSHOOTS batchSize
 *   (not possible in this linear add loop, but important to reason
 *   about), the condition would silently miss the flush.
 *   More importantly: the condition should be `>=` not `==` as a
 *   defensive measure. Strong candidates will also note this.
 *
 *   The PRIMARY Bug 3 interviewers should focus on:
 *   batchSize is never validated — if 0 or negative is passed, the
 *   inner `if (batch.Count == batchSize)` never triggers (Count starts
 *   at 0 and grows), resulting in a single enormous batch = all entries
 *   loaded into memory, defeating the streaming purpose entirely.
 *
 *   FIXED:
 *       if (batchSize <= 0) throw new ArgumentOutOfRangeException(nameof(batchSize));
 *
 * BUG 4 — Case-Inconsistent Dictionary Keys (CountByLevel)
 *   BUGGY  : var key = e.Level;   (uses raw case from input)
 *   FIXED  : var key = e.Level.ToUpperInvariant();
 *
 *   WHY    : The raw log data contains "ERROR" and "error" as separate
 *            level values. Using e.Level directly as the dictionary
 *            key produces two separate entries: "ERROR": 2 and
 *            "error": 1 — instead of the expected "ERROR": 3.
 *
 *            The fix is to normalise case before using as a key.
 *            ToUpperInvariant() is preferred over ToUpper() for
 *            culture-invariant comparisons.
 *
 *            Alternatively, construct the dictionary with a case-
 *            insensitive comparer:
 *            new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase)
 *            This approach is arguably more idiomatic.
 *
 * ============================================================
 */

using System;
using System.Collections.Generic;
using System.Linq;

public record LogEntry(string Level, DateTime Timestamp, string Message);

public class LogPipeline
{
    // 1. Lazy parse — FIX 1: iterate source directly, no ToList()
    public IEnumerable<LogEntry> ParseLines(IEnumerable<string> lines)
    {
        foreach (var line in lines)   // FIX 1
        {
            var parts = line.Split('|');
            if (parts.Length != 3) continue;
            if (!DateTime.TryParse(parts[1], out var ts)) continue;
            yield return new LogEntry(parts[0].Trim(), ts, parts[2].Trim());
        }
    }

    // 2. FIX 2: split into public wrapper (eager validation) + private iterator
    public IEnumerable<LogEntry> FilterByLevel(IEnumerable<LogEntry> entries, string level)
    {
        if (entries == null) throw new ArgumentNullException(nameof(entries));
        if (string.IsNullOrEmpty(level)) throw new ArgumentException("level required", nameof(level));
        return FilterByLevelCore(entries, level);
    }

    private IEnumerable<LogEntry> FilterByLevelCore(IEnumerable<LogEntry> entries, string level)
    {
        foreach (var e in entries)
            if (e.Level.Equals(level, StringComparison.OrdinalIgnoreCase))
                yield return e;
    }

    // 3. FIX 3: validate batchSize at the boundary
    public IEnumerable<string> BatchSummarise(IEnumerable<LogEntry> entries, int batchSize)
    {
        if (batchSize <= 0) throw new ArgumentOutOfRangeException(nameof(batchSize));

        var batch = new List<LogEntry>(batchSize);
        int batchNum = 0;

        foreach (var entry in entries)
        {
            batch.Add(entry);

            if (batch.Count >= batchSize)
            {
                batchNum++;
                yield return FormatBatch(batchNum, batch);
                batch.Clear();
            }
        }

        if (batch.Count > 0)
        {
            batchNum++;
            yield return FormatBatch(batchNum, batch);
        }
    }

    private static string FormatBatch(int n, List<LogEntry> batch) =>
        $"Batch {n}: {batch.Count} entries, " +
        $"first={batch[0].Timestamp:HH:mm:ss}, " +
        $"last={batch[batch.Count - 1].Timestamp:HH:mm:ss}";

    // 4. FIX 4: normalise level casing for consistent keys
    public Dictionary<string, int> CountByLevel(IEnumerable<LogEntry> entries)
    {
        // Option A: normalise key explicitly
        var counts = new Dictionary<string, int>();
        foreach (var e in entries)
        {
            var key = e.Level.ToUpperInvariant();   // FIX 4
            if (counts.ContainsKey(key))
                counts[key]++;
            else
                counts[key] = 1;
        }
        return counts;

        // Option B (idiomatic alternative — full marks):
        // return entries
        //     .GroupBy(e => e.Level, StringComparer.OrdinalIgnoreCase)
        //     .ToDictionary(g => g.Key.ToUpperInvariant(), g => g.Count());
    }
}

class Program
{
    static void Main()
    {
        var rawLines = new List<string>
        {
            "ERROR|2024-03-01 10:00:01|Disk full",
            "INFO|2024-03-01 10:00:02|Service started",
            "error|2024-03-01 10:00:03|Connection lost",
            "WARN|2024-03-01 10:00:04|High memory",
            "MALFORMED LINE",
            "INFO|not-a-date|Bad timestamp",
            "INFO|2024-03-01 10:00:05|Request received",
            "ERROR|2024-03-01 10:00:06|Timeout",
        };

        var pipeline = new LogPipeline();

        var entries = pipeline.ParseLines(rawLines);
        var errors  = pipeline.FilterByLevel(entries, "error");

        Console.WriteLine("=== Error entries ===");
        foreach (var e in errors)
            Console.WriteLine($"  {e.Timestamp:HH:mm:ss} — {e.Message}");

        Console.WriteLine("\n=== Batches (size=3) ===");
        var allEntries = pipeline.ParseLines(rawLines);
        foreach (var summary in pipeline.BatchSummarise(allEntries, 3))
            Console.WriteLine($"  {summary}");

        Console.WriteLine("\n=== Count by level ===");
        var allEntries2 = pipeline.ParseLines(rawLines);
        var counts = pipeline.CountByLevel(allEntries2);
        foreach (var kv in counts.OrderBy(k => k.Key))
            Console.WriteLine($"  {kv.Key}: {kv.Value}");
        // ERROR: 3, INFO: 2, WARN: 1
    }
}
