/*
 * ============================================================
 * ASSESSMENT CLASS 6 — ANSWER FILE (DO NOT SHARE WITH CANDIDATES)
 * Recursion, Memoization & Tree Traversal
 * ============================================================
 *
 * BUG SUMMARY
 * ───────────────────────────────────────────────────────────
 *
 * BUG 1 — Off-By-One in MaxDepth (leaf node returns 0 instead of 1)
 *   BUGGY  : if (!root.Children.Any()) return 0;
 *   FIXED  : if (!root.Children.Any()) return 1;
 *
 *   WHY    : A single leaf node (no children) is still a valid node
 *            and should have depth 1. Returning 0 for leaves means
 *            every path length is undercounted by 1.
 *
 *            Trace with the smoke-test tree:
 *              MaxDepth(DB Team)     → has no children → returns 0 (WRONG)
 *              MaxDepth(Backend)     → 1 + max(0) = 1 (WRONG, should be 2)
 *              MaxDepth(Engineering) → 1 + max(1, ...) = 2 (WRONG, should be 3)
 *
 *            With the fix:
 *              MaxDepth(DB Team)     → 1
 *              MaxDepth(Backend)     → 1 + max(1) = 2
 *              MaxDepth(Engineering) → 1 + max(2, 1) = 3  ✓
 *
 *   NOTE   : The null guard `if (root == null) return 0` is correct
 *            and must NOT be changed — it handles calls from the
 *            recursive Max() on an empty Children list.
 *
 * BUG 2 — MaxBy on an Empty Sequence Throws (FindHighestPaid)
 *   BUGGY  : allEmployees.MaxBy(e => e.Salary)
 *   FIXED  : allEmployees.MaxBy(e => e.Salary)   ← with a guard, OR:
 *            use FirstOrDefault after OrderByDescending, OR:
 *            use the overload that returns null on empty.
 *
 *   DETAILED WHY:
 *   In .NET 6+, Enumerable.MaxBy<TSource, TKey>() was introduced.
 *   It returns null (not throws) when the source is empty for
 *   reference types — so for `IEnumerable<Employee>` where Employee
 *   is a record (reference type), MaxBy returns null on empty input.
 *   This makes the code SAFE in .NET 6+.
 *
 *   HOWEVER — this is still a bug worth raising because:
 *   (a) If targeting .NET 5 or earlier, MaxBy doesn't exist and the
 *       developer would use .Max() which THROWS on empty sequences.
 *   (b) If Employee were a struct (value type), MaxBy would throw
 *       on empty sequences even in .NET 6+.
 *   (c) Relying on implicit "returns null on empty" behaviour for a
 *       reference type is fragile and non-obvious to readers.
 *
 *   CORRECT DEFENSIVE PATTERN:
 *       var all = GetAllEmployees(root).ToList();
 *       if (!all.Any()) return null;
 *       return all.MaxBy(e => e.Salary);
 *
 *   OR using explicit OrderBy:
 *       return GetAllEmployees(root)
 *           .OrderByDescending(e => e.Salary)
 *           .FirstOrDefault();   // always null-safe
 *
 *   INTERVIEWER NOTE: Award full marks to any candidate who:
 *   (1) Identifies the empty-sequence risk and explains when it would
 *       throw vs return null based on .NET version and type.
 *   (2) Proposes a defensive guard or alternative LINQ pattern.
 *
 * BUG 3 — Memoization Cache Re-Created on Every Call (MemoizedFibonacci)
 *   BUGGY  : public long MemoizedFibonacci(int n)
 *            {
 *                var memo = new Dictionary<int, long>();  // local variable!
 *                return Fib(n, memo);
 *            }
 *   FIXED  : Make the cache a private instance field (or static field).
 *
 *   WHY    : The memo dictionary is declared as a local variable inside
 *            MemoizedFibonacci. This means it is created fresh on every
 *            public call and thrown away when the call returns. Within a
 *            single call the memoization works correctly (Fib passes
 *            the same dict through recursion), but ACROSS calls there
 *            is zero caching. Calling MemoizedFibonacci(40) followed
 *            by MemoizedFibonacci(40) recomputes everything from scratch
 *            both times. The whole point of memoization is to persist
 *            the cache across invocations.
 *
 *   FIXED:
 *       private readonly Dictionary<int, long> _memo = new();
 *
 *       public long MemoizedFibonacci(int n)
 *       {
 *           if (n < 0) throw new ArgumentOutOfRangeException(nameof(n));
 *           return Fib(n, _memo);
 *       }
 *
 *   A strong candidate will also note that a static field would share
 *   the cache across ALL OrgChart instances, which could be desirable
 *   (global memo) or surprising (unexpected coupling). An instance
 *   field is the safer default.
 *
 * BUG 4 — Negative Guard in Wrong Method (MemoizedFibonacci)
 *   BUGGY  : The guard `if (n < 0) throw ...` is inside the private
 *            Fib() method, not the public MemoizedFibonacci().
 *   FIXED  : Move the guard to the public entry point.
 *
 *   WHY    : The negative check should be at the API boundary, not
 *            buried in the private recursive helper. When Fib() calls
 *            itself recursively (Fib(n-1, ...), Fib(n-2, ...)), n
 *            will never naturally go negative for valid inputs (the
 *            n==0 and n==1 base cases stop the recursion). So the guard
 *            inside Fib() is dead code for all valid inputs. If someone
 *            passes -1 to MemoizedFibonacci, the guard DOES fire on
 *            the first call — but this is misleading: the exception's
 *            stack trace will show `Fib()` not `MemoizedFibonacci()`,
 *            making the error harder to diagnose.
 *
 *   FIXED:
 *       public long MemoizedFibonacci(int n)
 *       {
 *           if (n < 0) throw new ArgumentOutOfRangeException(nameof(n));  // ← here
 *           return Fib(n, _memo);
 *       }
 *
 *       private long Fib(int n, Dictionary<int, long> memo)
 *       {
 *           // no guard needed here — n is always >= 0 from valid entry point
 *           if (n == 0) return 0;
 *           if (n == 1) return 1;
 *           ...
 *       }
 *
 * ============================================================
 */

using System;
using System.Collections.Generic;
using System.Linq;

public record Employee(string Name, decimal Salary);

public class Department
{
    public string Name { get; init; }
    public List<Employee> Employees { get; init; } = new();
    public List<Department> Children { get; init; } = new();
}

public class OrgChart
{
    // 1. Total headcount — no bugs
    public int TotalHeadcount(Department root)
    {
        if (root == null) return 0;
        int count = root.Employees.Count;
        foreach (var child in root.Children)
            count += TotalHeadcount(child);
        return count;
    }

    // 2. FIX 1: leaf node returns 1, not 0
    public int MaxDepth(Department root)
    {
        if (root == null) return 0;
        if (!root.Children.Any()) return 1;   // FIX 1

        return 1 + root.Children.Max(c => MaxDepth(c));
    }

    // 3. FIX 2: guard empty sequence explicitly
    public Employee FindHighestPaid(Department root)
    {
        if (root == null) return null;

        return GetAllEmployees(root)
            .OrderByDescending(e => e.Salary)
            .FirstOrDefault();  // FIX 2 — null-safe on empty sequence, any .NET version
    }

    private IEnumerable<Employee> GetAllEmployees(Department dept)
    {
        foreach (var e in dept.Employees)
            yield return e;

        foreach (var child in dept.Children)
            foreach (var e in GetAllEmployees(child))
                yield return e;
    }

    // FIX 3: cache is a persistent instance field, not a local variable
    private readonly Dictionary<int, long> _memo = new();

    // FIX 4: validation at public API boundary, not inside private recursive helper
    public long MemoizedFibonacci(int n)
    {
        if (n < 0) throw new ArgumentOutOfRangeException(nameof(n));   // FIX 4
        return Fib(n);
    }

    private long Fib(int n)   // FIX 3: uses instance _memo, no local dict
    {
        if (n == 0) return 0;
        if (n == 1) return 1;

        if (_memo.TryGetValue(n, out var cached))
            return cached;

        var result = Fib(n - 1) + Fib(n - 2);
        _memo[n] = result;
        return result;
    }
}

class Program
{
    static void Main()
    {
        var root = new Department
        {
            Name = "Engineering",
            Employees = new List<Employee>
            {
                new("Alice", 120_000m),
                new("Bob",    95_000m),
            },
            Children = new List<Department>
            {
                new Department
                {
                    Name = "Backend",
                    Employees = new List<Employee>
                    {
                        new("Carol", 110_000m),
                        new("Dave",   85_000m),
                    },
                    Children = new List<Department>
                    {
                        new Department
                        {
                            Name = "DB Team",
                            Employees = new List<Employee> { new("Eve", 130_000m) }
                        }
                    }
                },
                new Department
                {
                    Name = "Frontend",
                    Employees = new List<Employee> { new("Frank", 98_000m) }
                }
            }
        };

        var chart = new OrgChart();

        Console.WriteLine($"Total headcount : {chart.TotalHeadcount(root)}");   // 6
        Console.WriteLine($"Max depth       : {chart.MaxDepth(root)}");         // 3
        Console.WriteLine($"Highest paid    : {chart.FindHighestPaid(root)?.Name}");  // Eve
        Console.WriteLine($"Fib(10)         : {chart.MemoizedFibonacci(10)}");  // 55
        Console.WriteLine($"Fib(0)          : {chart.MemoizedFibonacci(0)}");   // 0

        try { chart.MemoizedFibonacci(-1); }
        catch (ArgumentOutOfRangeException) { Console.WriteLine("Negative n correctly rejected"); }
    }
}
