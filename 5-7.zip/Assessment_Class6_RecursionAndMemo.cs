/*
 * ============================================================
 * ASSESSMENT CLASS 6 — Recursion, Memoization & Tree Traversal
 * ============================================================
 * TOPIC      : Problem Solving, Data Structures, Performance,
 *              Critical Thinking
 * DIFFICULTY : Hard
 *
 * DESCRIPTION:
 *   You are given a simple N-ary tree of Department nodes (each
 *   department can have any number of child departments and
 *   employees). You must implement three operations:
 *
 *     1. TotalHeadcount(Department root)
 *        Returns the TOTAL number of employees across the entire
 *        tree rooted at `root` (including all descendants).
 *
 *     2. MaxDepth(Department root)
 *        Returns the maximum depth of the tree. A single node with
 *        no children has depth 1. A root with one child has depth 2.
 *
 *     3. FindHighestPaid(Department root)
 *        Returns the Employee with the highest Salary in the entire
 *        tree. Returns null if no employees exist anywhere.
 *
 *     4. MemoizedFibonacci(int n)
 *        Returns the nth Fibonacci number (0-indexed: F(0)=0, F(1)=1).
 *        Must use memoization to avoid exponential recursion.
 *        Must handle n < 0 by throwing ArgumentOutOfRangeException.
 *
 *   This code compiles but contains FOUR bugs.
 *   Find and fix all of them.
 *
 * WHAT TO LOOK FOR:
 *   - An off-by-one in tree depth calculation
 *   - A null reference risk in FindHighestPaid's LINQ
 *   - A memoization cache that is re-created on every call
 *   - A missing base-case guard in MemoizedFibonacci
 * ============================================================
 */

using System;
using System.Collections.Generic;
using System.Linq;

public record Employee(string Name, decimal Salary);

public class Department
{
    public string Name { get; init; }
    public List<Employee> Employees { get; init; } = new();
    public List<Department> Children { get; init; } = new();
}

public class OrgChart
{
    // 1. Total headcount
    public int TotalHeadcount(Department root)
    {
        if (root == null) return 0;
        int count = root.Employees.Count;
        foreach (var child in root.Children)
            count += TotalHeadcount(child);
        return count;
    }

    // 2. Max depth
    public int MaxDepth(Department root)
    {
        if (root == null) return 0;
        if (!root.Children.Any()) return 0;  // BUG 1

        return 1 + root.Children.Max(c => MaxDepth(c));
    }

    // 3. Highest paid employee across the whole tree
    public Employee FindHighestPaid(Department root)
    {
        if (root == null) return null;

        var allEmployees = GetAllEmployees(root);
        return allEmployees.MaxBy(e => e.Salary);  // BUG 2
    }

    private IEnumerable<Employee> GetAllEmployees(Department dept)
    {
        foreach (var e in dept.Employees)
            yield return e;

        foreach (var child in dept.Children)
            foreach (var e in GetAllEmployees(child))
                yield return e;
    }

    // 4. Memoized Fibonacci
    public long MemoizedFibonacci(int n)
    {
        var memo = new Dictionary<int, long>();  // BUG 3
        return Fib(n, memo);
    }

    private long Fib(int n, Dictionary<int, long> memo)
    {
        if (n < 0) throw new ArgumentOutOfRangeException(nameof(n));  // BUG 4
        if (n == 0) return 0;
        if (n == 1) return 1;

        if (memo.TryGetValue(n, out var cached))
            return cached;

        var result = Fib(n - 1, memo) + Fib(n - 2, memo);
        memo[n] = result;
        return result;
    }
}


/* ---------- Quick smoke test (do NOT modify) ---------- */
class Program
{
    static void Main()
    {
        /*
         *  Root (Engineering)
         *  ├── Alice, Bob
         *  ├── Backend
         *  │   ├── Carol, Dave
         *  │   └── DB Team
         *  │       └── Eve
         *  └── Frontend
         *      └── Frank
         */
        var root = new Department
        {
            Name = "Engineering",
            Employees = new List<Employee>
            {
                new("Alice", 120_000m),
                new("Bob",    95_000m),
            },
            Children = new List<Department>
            {
                new Department
                {
                    Name = "Backend",
                    Employees = new List<Employee>
                    {
                        new("Carol", 110_000m),
                        new("Dave",   85_000m),
                    },
                    Children = new List<Department>
                    {
                        new Department
                        {
                            Name = "DB Team",
                            Employees = new List<Employee> { new("Eve", 130_000m) }
                        }
                    }
                },
                new Department
                {
                    Name = "Frontend",
                    Employees = new List<Employee> { new("Frank", 98_000m) }
                }
            }
        };

        var chart = new OrgChart();

        Console.WriteLine($"Total headcount : {chart.TotalHeadcount(root)}");
        // Expected: 6

        Console.WriteLine($"Max depth       : {chart.MaxDepth(root)}");
        // Expected: 3  (Engineering → Backend → DB Team)

        Console.WriteLine($"Highest paid    : {chart.FindHighestPaid(root)?.Name}");
        // Expected: Eve ($130,000)

        Console.WriteLine($"Fib(10)         : {chart.MemoizedFibonacci(10)}");
        // Expected: 55

        Console.WriteLine($"Fib(0)          : {chart.MemoizedFibonacci(0)}");
        // Expected: 0

        try { chart.MemoizedFibonacci(-1); }
        catch (ArgumentOutOfRangeException) { Console.WriteLine("Negative n correctly rejected"); }
    }
}
